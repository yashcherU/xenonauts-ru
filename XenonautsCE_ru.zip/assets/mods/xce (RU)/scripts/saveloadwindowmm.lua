require "scripts/style"

MakeDialog
{
	SaveLoadWindow
	{
	  x = 0,
	  y = 0,
	  w = kMax,
	  h = kMax,
	  
	  
	  --image = "uitextures/commonbg",
    bordersize = 2,
	
	hasExternalBorders = false, --!important!
    
    NonUniformScaledImage
    {
      x = 0,
      y = 0,
      w = kMax,
      h = 1,
      
  	  image = "uitextures/black",
  	  tint  = Black50A,
    },

    ListControl
    {
      name = "savelist",
      x = 5,
      y = 5,
      w = kMax,
      h = kMax - 42 * screenScaleY - 5,
      font = XenonautsLabelFontMediumBlack,
      fontScale = screenScaleY,
      hcolor = WhiteColor,
      hswl = true,

      column1x = 1   * screenScaleY,
      column1w = 366 * screenScaleY,
      column2x = 365 * screenScaleY,
      column2w = 215 * screenScaleY,
    
      TiledImage
      {
        name = "scrollbar",
        x = kMax - 8,
        y = 0,
        w = kMax -1,
        h = kMax,
        image = "uitextures/scrollbar_black",
        bordersize = 4,

        NonUniformScaledImage
        {
          name  = "scrollbarBtn",
          x = 1,
          y = 0,
          w = 6,
          h = 5,
          image = "uitextures/black",
        },
      },
    },

    Window
    {
      x = kCenter,
      y = kMax - 40 * screenScaleY - 5,
      w = kMax,
      h = 35 * screenScaleY,
    
      Window
      {
        x = kCenter - 40 * screenScaleY,
        y = 0,
        w = 180 * screenScaleY,
        h = 35 * screenScaleY,
    
	  SetStyle( XenonautsTiledButtonStyleMenu2 ),
	  TiledButton
        {
          name = "load",
          default = true,
          x = 0,
          y = kCenter,
          w = kMax,
          h = kMax,
		  bordersize = 2,
          label = "SaveGameDialog.ResumeOperation",
          font = XenonautsLabelFontMediumBlack,
          fontScale = screenScaleY * 1.25,

          command = 
            function()
              PopModal( "mainmenu" );
              LoadGame();
            end,
        },
	  },
	  
	  SetStyle( XenonautsTiledButtonStyleMenu2 ),
	  TiledButton
		{
		  name = "deleteGame",
		  x = kMax - 100 * screenScaleY,
		  y = kCenter,
		  w = 90 * screenScaleY,
		  h = kMax,
			  bordersize = 2,
		  label = "SaveGameDialog.DoDelete",
		  font = XenonautsLabelFontMedium,
		  fontScale = screenScaleY,
		  
		  command = 
			function()
			  DeleteGame();
			end,
		},
	  
    },
	

    ScalingText
    {
      name = "NoSave",
      font = XenonautsLabelFontMediumBlack,
      x = 0,
      y = 0,
      w = kMax,
      h = kMax,
      fontScale = screenScaleY * 1.5,
	    flags = kHAlignCenter + kVAlignCenter,
      label = "SaveGameDialog.NoSavedGames",
    },
	},
}
