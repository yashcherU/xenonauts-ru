require "scripts/style"

MakeDialog
{
	name = "epilogue",
	GameOverScreen
	{
	  x = kCenter,
	  y = kCenter,
	  w = kMax,
	  h = kMax,
	  
	  image = "backgrounds/mainmenu/victory",
		
		GSDialog
		{
		x = kCenter,
		y = kCenter,
		
		fit = true,
		movable = false,
		
		  TiledImage
		  {
			  name  = "backgroundimage",
			  image = "uitextures/transparent",
			w     = 330 * screenScaleX,
			h     = 520 * screenScaleY,
			bordersize = 2,
			
			sizetochildren = true,
			sizetochildrenborder = 5,
			
		  ScalingText
		  {
			name = "name",
			x = 5,
			y = 0,
			w = kMax - 5,
			h = 65 * screenScaleY,
			flags = kHAlignCenter + kVAlignCenter,
			label = "GameOver.Victory.Epilogue.Title",
			font = XenonautsLabelFontMedium,
			fontScale = 1.2*screenScaleY,
		  },
		  ScalingText
		  {
			name = "message",
			x = 10 * screenScaleY,
			y = 0,
			w = kMax - (20 * screenScaleY),
			h = 440 * screenScaleY,
			flags = kHAlignLeft + kVAlignCenter,
			label = "GameOver.Victory.Epilogue",
			font = XenopediaMain,
			fontScale = 1.05*screenScaleY,
		  },

		  
			
		  SetStyle( XenonautsTiledButton2Style ),
		  TiledButton
		  {
			name = "cancel",
			default = true,
			cancel = true,
			x = 5,
			y = 0,
			w = kMax - 5,
			h = 20 * screenScaleY,
				bordersize = 2,
			label = "GameOver.Victory.ReturnToMenu",
			font = XenonautsLabelFontMedium,
			fontScale = screenScaleY,
			
			command = 
			  function()
				  PopModal( "epilogue" );
				  DisplayDialog { "scripts/mainmenu.lua" };
			  end,
		  },
		  },
		},
	},
}
