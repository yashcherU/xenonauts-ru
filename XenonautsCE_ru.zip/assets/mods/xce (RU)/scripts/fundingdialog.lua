require "scripts/style"

local windowW = Floor( 1024 * 0.35 ) * screenScaleX;
local windowH = Floor(  768 * 0.90 ) * screenScaleY;
local imageW  = windowW - 20;
local imageH  = Floor( imageW * 0.428 ); --21:9
local colW 	  = ( imageW - 4 ) / 3;

MakeDialog
{
	name = "fundingreport",

	FundingScreen
	{
		x = kCenter,
		y = kCenter,
		w = windowW,
		h = windowH,

		movable = false,
		fit = true,
		
		TiledImage
		{
			name  = "backgroundimage",
			image = "uitextures/transparent",
			w     = kMax,
			h     = kMax,
			bordersize = 1,

			sizetochildren = true,
			sizetochildrenborder = 5,
			
			ScalingText
			{
				name = "title",
				x = 5,
				y = 0,
				w = kMax - 5,
				h = 62 * screenScaleY,
				flags = kHAlignCenter + kVAlignCenter,
				label = "Funding.Title",
				font = XenonautsLabelFontMedium,
				fontScale = 1.4 * screenScaleY,
			},
			ScalingText
			{
				name = "desc",
				x = 5,
				y = 0,
				w = kMax - 5,
				h = 20 * screenScaleY,
				flags = kHAlignCenter + kVAlignBottom,
				label = "Funding.Desc",
				font = XenonautsLabelFontMedium,
				fontScale = 0.8 * screenScaleY,
			},
			
			TiledImage
			{
				name  = "frame",
				image = "uitextures/funding_frame",
				x = 10,
				y = 0,
				w = imageW,
				h = imageH,
				bordersize = 1,
				
				NonUniformScaledImage
				{
					name = "headerImg",
					x = 1,
					y = 1,
					w = imageW-2,
					h = imageH-2,
					
					image = "backgrounds/funding",
					bordersize = 2,
				},
			},
			
			ScalingText
			{
				name = "situationText",
				x = 5,
				y = 5,
				w = kMax - 5,
				h = 30 * screenScaleY,
				flags = kHAlignCenter + kVAlignCenter,
				label = "undefined",
				font = XenonautsLabelFontMedium,
				fontScale = 1.0 * screenScaleY,
			},
			
			ScalingText
			{
				name = "situationText2",
				x = 5,
				y = 0,
				w = kMax - 5,
				h = 20 * screenScaleY,
				flags = kHAlignCenter + kVAlignCenter,
				label = "undefined",
				font = XenonautsLabelFontMedium,
				fontScale = 0.8 * screenScaleY,
			},
			
			TitledFrame
			{
				name = "table",
				x = 0,
				y = 0,
				w = kMax,
				h = 26 * screenScaleY + ( 20 * screenScaleY ) * 10 + 10,
				
				-- First column, region names
				TitledFrame
				{
					name  = "static",
					x     = 10,
					y     = 10,
					w     = colW,
					h     = 26 * screenScaleY + ( 20 * screenScaleY ) * 10,
					headimage = "uitextures/frametop",
					bodyimage = "uitextures/research/framebottomcol2",
					bordersize = 2,
					headersize = 24 * screenScaleY,

					ScalingText
					{
						font = XenonautsLabelFontMedium,
						name = "static",
						x = 10,
						y = 0,
						w = kMax,
						h = 26 * screenScaleY,
						fontScale = 0.8 * screenScaleY,
						flags = kHAlignLeft + kVAlignCenter,
						label = "Funding.RegionName",
						outline = 1,
					},

					ScalingText
					{
						name = "reg1N",
						x = 10,
						y = 26 * screenScaleY,
						w = kMax,
						h = 20 * screenScaleY,
						flags = kHAlignLeft + kVAlignCenter,
						label = "NA",
						font = XenonautsLabelFontSmall,
						fontScale = screenScaleY,
						outline = 1,
					},
					ScalingText
					{
						name = "reg2N",
						x = 10,
						y = 26 * screenScaleY + ( 20 * screenScaleY ) * 1,
						w = kMax,
						h = 20 * screenScaleY,
						flags = kHAlignLeft + kVAlignCenter,
						label = "SU",
						font = XenonautsLabelFontSmall,
						fontScale = screenScaleY,
						outline = 1,
					},
					ScalingText
					{
						name = "reg3N",
						x = 10,
						y = 26 * screenScaleY + ( 20 * screenScaleY ) * 2,
						w = kMax,
						h = 20 * screenScaleY,
						flags = kHAlignLeft + kVAlignCenter,
						label = "EU",
						font = XenonautsLabelFontSmall,
						fontScale = screenScaleY,
						outline = 1,
					},
					ScalingText
					{
						name = "reg4N",
						x = 10,
						y = 26 * screenScaleY + ( 20 * screenScaleY ) * 3,
						w = kMax,
						h = 20 * screenScaleY,
						flags = kHAlignLeft + kVAlignCenter,
						label = "CH",
						font = XenonautsLabelFontSmall,
						fontScale = screenScaleY,
						outline = 1,
					},
					ScalingText
					{
						name = "reg5N",
						x = 10,
						y = 26 * screenScaleY + ( 20 * screenScaleY ) * 4,
						w = kMax,
						h = 20 * screenScaleY,
						flags = kHAlignLeft + kVAlignCenter,
						label = "AU",
						font = XenonautsLabelFontSmall,
						fontScale = screenScaleY,
						outline = 1,
					},
					ScalingText
					{
						name = "reg6N",
						x = 10,
						y = 26 * screenScaleY + ( 20 * screenScaleY ) * 5,
						w = kMax,
						h = 20 * screenScaleY,
						flags = kHAlignLeft + kVAlignCenter,
						label = "SAF",
						font = XenonautsLabelFontSmall,
						fontScale = screenScaleY,
						outline = 1,
					},
					ScalingText
					{
						name = "reg7N",
						x = 10,
						y = 26 * screenScaleY + ( 20 * screenScaleY ) * 6,
						w = kMax,
						h = 20 * screenScaleY,
						flags = kHAlignLeft + kVAlignCenter,
						label = "NAF",
						font = XenonautsLabelFontSmall,
						fontScale = screenScaleY,
						outline = 1,
					},
					ScalingText
					{
						name = "reg8N",
						x = 10,
						y = 26 * screenScaleY + ( 20 * screenScaleY ) * 7,
						w = kMax,
						h = 20 * screenScaleY,
						flags = kHAlignLeft + kVAlignCenter,
						label = "SA",
						font = XenonautsLabelFontSmall,
						fontScale = screenScaleY,
						outline = 1,
					},
					ScalingText
					{
						name = "reg9N",
						x = 10,
						y = 26 * screenScaleY + ( 20 * screenScaleY ) * 8,
						w = kMax,
						h = 20 * screenScaleY,
						flags = kHAlignLeft + kVAlignCenter,
						label = "ME",
						font = XenonautsLabelFontSmall,
						fontScale = screenScaleY,
						outline = 1,
					},
					ScalingText
					{
						name = "reg10N",
						x = 10,
						y = 26 * screenScaleY + ( 20 * screenScaleY ) * 9,
						w = kMax,
						h = 20 * screenScaleY,
						flags = kHAlignLeft + kVAlignCenter,
						label = "CA",
						font = XenonautsLabelFontSmall,
						fontScale = screenScaleY,
						outline = 1,
					},
				},
				
				-- Second column, monthly change
				TitledFrame
				{
					name  = "static",
					x     = 10 + ( colW + 2 ) * 1,
					y     = 10,
					w     = colW,
					h     = 26 * screenScaleY + ( 20 * screenScaleY ) * 10,
					headimage = "uitextures/frametop",
					bodyimage = "uitextures/research/framebottomcol2",
					bordersize = 2,
					headersize = 24 * screenScaleY,

					ScalingText
					{
						font = XenonautsLabelFontMedium,
						name = "static",
						x = 10,
						y = 0,
						w = kMax,
						h = 26 * screenScaleY,
						fontScale = 0.8 * screenScaleY,
						flags = kHAlignCenter + kVAlignCenter,
						label = "Funding.MonthlyChange",
						outline = 1,
					},

					ScalingText
					{
						name = "reg1MC",
						x = 0,
						y = 26 * screenScaleY,
						w = kMax,
						h = 20 * screenScaleY,
						flags = kHAlignCenter + kVAlignCenter,
						label = "undefined",
						font = XenonautsLabelFontSmall,
						fontScale = screenScaleY,
						outline = 1,
					},
					ScalingText
					{
						name = "reg2MC",
						x = 0,
						y = 26 * screenScaleY + ( 20 * screenScaleY ) * 1,
						w = kMax,
						h = 20 * screenScaleY,
						flags = kHAlignCenter + kVAlignCenter,
						label = "undefined",
						font = XenonautsLabelFontSmall,
						fontScale = screenScaleY,
						outline = 1,
					},
					ScalingText
					{
						name = "reg3MC",
						x = 0,
						y = 26 * screenScaleY + ( 20 * screenScaleY ) * 2,
						w = kMax,
						h = 20 * screenScaleY,
						flags = kHAlignCenter + kVAlignCenter,
						label = "undefined",
						font = XenonautsLabelFontSmall,
						fontScale = screenScaleY,
						outline = 1,
					},
					ScalingText
					{
						name = "reg4MC",
						x = 0,
						y = 26 * screenScaleY + ( 20 * screenScaleY ) * 3,
						w = kMax,
						h = 20 * screenScaleY,
						flags = kHAlignCenter + kVAlignCenter,
						label = "undefined",
						font = XenonautsLabelFontSmall,
						fontScale = screenScaleY,
						outline = 1,
					},
					ScalingText
					{
						name = "reg5MC",
						x = 0,
						y = 26 * screenScaleY + ( 20 * screenScaleY ) * 4,
						w = kMax,
						h = 20 * screenScaleY,
						flags = kHAlignCenter + kVAlignCenter,
						label = "undefined",
						font = XenonautsLabelFontSmall,
						fontScale = screenScaleY,
						outline = 1,
					},
					ScalingText
					{
						name = "reg6MC",
						x = 0,
						y = 26 * screenScaleY + ( 20 * screenScaleY ) * 5,
						w = kMax,
						h = 20 * screenScaleY,
						flags = kHAlignCenter + kVAlignCenter,
						label = "undefined",
						font = XenonautsLabelFontSmall,
						fontScale = screenScaleY,
						outline = 1,
					},
					ScalingText
					{
						name = "reg7MC",
						x = 0,
						y = 26 * screenScaleY + ( 20 * screenScaleY ) * 6,
						w = kMax,
						h = 20 * screenScaleY,
						flags = kHAlignCenter + kVAlignCenter,
						label = "undefined",
						font = XenonautsLabelFontSmall,
						fontScale = screenScaleY,
						outline = 1,
					},
					ScalingText
					{
						name = "reg8MC",
						x = 0,
						y = 26 * screenScaleY + ( 20 * screenScaleY ) * 7,
						w = kMax,
						h = 20 * screenScaleY,
						flags = kHAlignCenter + kVAlignCenter,
						label = "undefined",
						font = XenonautsLabelFontSmall,
						fontScale = screenScaleY,
						outline = 1,
					},
					ScalingText
					{
						name = "reg9MC",
						x = 0,
						y = 26 * screenScaleY + ( 20 * screenScaleY ) * 8,
						w = kMax,
						h = 20 * screenScaleY,
						flags = kHAlignCenter + kVAlignCenter,
						label = "undefined",
						font = XenonautsLabelFontSmall,
						fontScale = screenScaleY,
						outline = 1,
					},
					ScalingText
					{
						name = "reg10MC",
						x = 0,
						y = 26 * screenScaleY + ( 20 * screenScaleY ) * 9,
						w = kMax,
						h = 20 * screenScaleY,
						flags = kHAlignCenter + kVAlignCenter,
						label = "undefined",
						font = XenonautsLabelFontSmall,
						fontScale = screenScaleY,
						outline = 1,
					},
				},
				
				-- Third column, region funding
				TitledFrame
				{
					name  = "static",
					x     = 10 + ( colW + 2 ) * 2,
					y     = 10,
					w     = colW,
					h     = 26 * screenScaleY + ( 20 * screenScaleY ) * 10,
					headimage = "uitextures/frametop",
					bodyimage = "uitextures/research/framebottomcol2",
					bordersize = 2,
					headersize = 24 * screenScaleY,

					ScalingText
					{
						font = XenonautsLabelFontMedium,
						name = "static",
						x = 10,
						y = 0,
						w = kMax,
						h = 26 * screenScaleY,
						fontScale = 0.8 * screenScaleY,
						flags = kHAlignCenter + kVAlignCenter,
						label = "Funding.RegionFunding",
						outline = 1,
					},

					ScalingText
					{
						name = "reg1TF",
						x = 0,
						y = 26 * screenScaleY,
						w = kMax,
						h = 20 * screenScaleY,
						flags = kHAlignCenter + kVAlignCenter,
						label = "undefined",
						font = XenonautsLabelFontSmall,
						fontScale = screenScaleY,
						outline = 1,
					},
					ScalingText
					{
						name = "reg2TF",
						x = 0,
						y = 26 * screenScaleY + ( 20 * screenScaleY ) * 1,
						w = kMax,
						h = 20 * screenScaleY,
						flags = kHAlignCenter + kVAlignCenter,
						label = "undefined",
						font = XenonautsLabelFontSmall,
						fontScale = screenScaleY,
						outline = 1,
					},
					ScalingText
					{
						name = "reg3TF",
						x = 0,
						y = 26 * screenScaleY + ( 20 * screenScaleY ) * 2,
						w = kMax,
						h = 20 * screenScaleY,
						flags = kHAlignCenter + kVAlignCenter,
						label = "undefined",
						font = XenonautsLabelFontSmall,
						fontScale = screenScaleY,
						outline = 1,
					},
					ScalingText
					{
						name = "reg4TF",
						x = 0,
						y = 26 * screenScaleY + ( 20 * screenScaleY ) * 3,
						w = kMax,
						h = 20 * screenScaleY,
						flags = kHAlignCenter + kVAlignCenter,
						label = "undefined",
						font = XenonautsLabelFontSmall,
						fontScale = screenScaleY,
						outline = 1,
					},
					ScalingText
					{
						name = "reg5TF",
						x = 0,
						y = 26 * screenScaleY + ( 20 * screenScaleY ) * 4,
						w = kMax,
						h = 20 * screenScaleY,
						flags = kHAlignCenter + kVAlignCenter,
						label = "undefined",
						font = XenonautsLabelFontSmall,
						fontScale = screenScaleY,
						outline = 1,
					},
					ScalingText
					{
						name = "reg6TF",
						x = 0,
						y = 26 * screenScaleY + ( 20 * screenScaleY ) * 5,
						w = kMax,
						h = 20 * screenScaleY,
						flags = kHAlignCenter + kVAlignCenter,
						label = "undefined",
						font = XenonautsLabelFontSmall,
						fontScale = screenScaleY,
						outline = 1,
					},
					ScalingText
					{
						name = "reg7TF",
						x = 0,
						y = 26 * screenScaleY + ( 20 * screenScaleY ) * 6,
						w = kMax,
						h = 20 * screenScaleY,
						flags = kHAlignCenter + kVAlignCenter,
						label = "undefined",
						font = XenonautsLabelFontSmall,
						fontScale = screenScaleY,
						outline = 1,
					},
					ScalingText
					{
						name = "reg8TF",
						x = 0,
						y = 26 * screenScaleY + ( 20 * screenScaleY ) * 7,
						w = kMax,
						h = 20 * screenScaleY,
						flags = kHAlignCenter + kVAlignCenter,
						label = "undefined",
						font = XenonautsLabelFontSmall,
						fontScale = screenScaleY,
						outline = 1,
					},
					ScalingText
					{
						name = "reg9TF",
						x = 0,
						y = 26 * screenScaleY + ( 20 * screenScaleY ) * 8,
						w = kMax,
						h = 20 * screenScaleY,
						flags = kHAlignCenter + kVAlignCenter,
						label = "undefined",
						font = XenonautsLabelFontSmall,
						fontScale = screenScaleY,
						outline = 1,
					},
					ScalingText
					{
						name = "reg10TF",
						x = 0,
						y = 26 * screenScaleY + ( 20 * screenScaleY ) * 9,
						w = kMax,
						h = 20 * screenScaleY,
						flags = kHAlignCenter + kVAlignCenter,
						label = "undefined",
						font = XenonautsLabelFontSmall,
						fontScale = screenScaleY,
						outline = 1,
					},
				},
			},
			
			ScalingText
			{
				name = "summary",
				x = 5,
				y = 5,
				w = kMax - 5,
				h = 30 * screenScaleY,
				flags = kHAlignCenter + kVAlignCenter,
				label = "undefined",
				font = XenonautsLabelFontMedium,
				fontScale = 0.9 * screenScaleY,
			},
			
			ScalingText
			{
				name = "netFunding",
				x = 5,
				y = 0,
				w = kMax - 5,
				h = 20 * screenScaleY,
				flags = kHAlignCenter + kVAlignCenter,
				label = "undefined",
				font = XenonautsLabelFontMedium,
				fontScale = 1.2 * screenScaleY,
			},
			
			SetStyle( XenonautsTiledButton2Style ),
			TiledButton
			{
				name = "close",
				default = true,
				cancel = true,
				x = 10,
				y = 5,
				w = kMax - 10,
				h = 26 * screenScaleY,
				bordersize = 2,
				label = "Funding.Close",
				font = XenonautsLabelFontMedium,
				fontScale = 1.1 * screenScaleY,

				command = 
					function()
						PopModal( "fundingreport" );
						MessageBoxClosed();
					end,
			},
		},
	},
}
