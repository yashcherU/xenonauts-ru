-- Main game loop
function Main()

	-- This is technically not needed at the start of main, but it's included
	-- here to remind Playground users to call it before they call Load() again,
	-- so that their progress bar will work correctly.
	LoaderReset();

	DoModal( "splashscreen/splashscreen.lua" );

	-- Push the game selection screen
	-- while true do
		-- DoMainWindow( "scripts/gamescreen.lua" );
		DoModal( "scripts/gamescreen.lua" );
		-- DoMainWindow will exit only if there are NO windows currently on the stack, so
		-- a PopModal()/PushModal() combination will not cause this to loop.
	-- end
end

return Main
