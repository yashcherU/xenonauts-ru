MakeDialog
{
    name = "splashscreen",
    Bitmap
    {
        name  = "splashscreenimage",
        x = kCenter,
        y = kCenter,
        image = "splashscreen/image",
        loadNow = true
    }
}
