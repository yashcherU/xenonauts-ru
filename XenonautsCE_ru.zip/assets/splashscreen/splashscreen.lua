GeoscapeFont = "fonts/xenonauts.mvec";
WhiteColor          = Color(255,255,255,255);
XenonautsVersionFont = {
  GeoscapeFont,
  16,
  WhiteColor
};


MakeDialog
{
    name = "splashscreen",
    Bitmap
    {
        name  = "splashscreenimage",
        x = kCenter,
        y = kCenter - 20 * screenScaleY,
        image = SplashScreenImage,
        loadNow = true
    },
    ScalingText
    {
        name = "version",
        x = kCenter,
        y = kMax - 40 * screenScaleY,
        w = kMax,
        h = 30 * screenScaleY,
        font = XenonautsVersionFont,
        flags = kHAlignCenter + kVAlignCenter,
        label = SplashScreenVersion
    }
}
