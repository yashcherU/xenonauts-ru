━━━━━━━━┓━━━┓┓━┏┓━━━┓┓━┏┓━━━┓━━
━━━━━┏━┓┃┏━┓┃┃━┃┃┏━┓┃┃━┃┃┏━━┛━━
┏┓━┏┓┃━┃┃┗━━┓┗━┛┃┃━┗┛┗━┛┃┗━━┓━┓
┃┃━┃┃┗━┛┃━━┓┃┏━┓┃┃━┏┓┏━┓┃┏━━┛┏┛
┃┗━┛┃┏━┓┃┗━┛┃┃━┃┃┗━┛┃┃━┃┃┗━━┓┃━
┗━┓┏┛┛━┗┛━━━┛┛━┗┛━━━┛┛━┗┛━━━┛┛━
┏━┛┃━━━━━━━━━━━━━━━━━━━━━━━━━━━
┗━━┛━━━━━━━━━━━━━━━━━━━━━━━━━━━
2024-10-12
Кастомизация перевода следующих модов:
	Armoured Assault!
	Extended Weapon Descriptions for Fighters
	Furies, Terror, and Dreadnoughts Oh My
	Lore+
	X:CE Balance Adjustments
	X:CE Base Mod

>выполнить установку Xenonauts_1.65W(2.3.0.13)_gog
>выполнить установку Xenonauts: Community Edition 0.35.1
>распаковать архив с модами в папку c установленной игрой [c:\GOG Games\Xenonauts\] с заменой содержимого папок fonts, launcher, splashscreen (копии заменяемых файлов имеют в конце нижнее подчёркивание)
>перед запуском игры очистить c:\Users\User\AppData\Roaming\Goldhawk Interactive\Xenonauts\
>выставить порядок модов в лаунчере в правильном приоритете, например так:

	[XCE] Xenonauts Fix Pack

	Ambience Forest
	Khall's More Portraits
	Khall's Tundra Tileset
	NewCars
	Random Map Pack Arctic Collection
	Random Map Pack Desert Style
	Random Map Pack Farm Edition
	Restored Community Map Pack
	Skitso's Alien Base Booster Pack
	Skitso's Improved Tile Art Pack
	Skitso's Ultimate Megamix Map Pack 2000
	Tropical and Swamp Tileset
	X:CE Extra Maps Pack

	Armoured Assault! (RU)
	Armoured Assault!
	Extended Weapon Descriptions for Fighters (RU)
	Extended Weapon Descriptions for Fighters
	Furies, Terror, and Dreadnoughts Oh My (RU)
	Furies, Terror, and Dreadnoughts Oh My
	Lore+ (RU)
	Lore+
	X:CE Balance Adjustments (RU)
	X:CE Base Mod (RU)

	X:CE Balance Adjustments
	X:CE Settings
	X:CE Base Mod