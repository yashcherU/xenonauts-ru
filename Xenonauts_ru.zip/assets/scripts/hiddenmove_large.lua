require "scripts/style"

function fexit_on()
	CloseWindow();
end

AlienTurnIconFont =
{
	GeoscapeFont,
	42,
	WhiteColor,
};

MakeDialog
{
  name = "hiddenmove",
  
  AIMove
  {
    x=0,
    y=0,
    w=kMax,
    h=kMax,
    
	Window
	{
		name = "hiddenmove_scr",
		x=0,
		y=0,
		w=kMax,
		h=kMax,
    
		TiledImage
		{
			name = "black_backgnd",
			x = 0,
			y = 0,
			w = kMax,
			h = kMax,
			image = "uitextures/black",
			tint = Color( 255, 255, 255, 128 );
		},
		
 		NonUniformScaledImage
		{
			name = "hiddenmove_img",
			x = kCenter,
			y = kCenter - 65,
			w = 1064 / 1.389 * screenScaleY,
			h = 680 / 1.389 * screenScaleY,
			image = "gui/GroundCombat/hiddenmovement/hiddenmovement",
		},
	},
	
	Window
	{
		name  = "alienturn_msg",
		x = kCenter,
		y = 20 * screenScaleY,
		w = 320 * screenScaleX,
		h = 42 * screenScaleY,
		
		NonUniformScaledImage
		{
			name  = "alienturn_icon",
			x = 10 * screenScaleX,
			y = 0,
			w = 42 * screenScaleY,
			h = 42 * screenScaleY,
			image = "gui/GroundCombat/alienturn_icon",
		},
		
		ScalingText
		{
			name = "alienturn_text",
			x = 50 * screenScaleX,
			y = 0,
			w = 320 * screenScaleX,
			h = 42 * screenScaleY,
			label = "hiddenmove.text",
			font = AlienTurnIconFont,
			fontScale = screenScaleY,
			outline = 2,
		},
	},
	
  },

}
