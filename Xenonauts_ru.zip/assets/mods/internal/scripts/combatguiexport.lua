
--require( "scripts/style.lua" );

function fexit_on()
	CloseWindow();
end

soldier_stats_graphics = 
{
	"uitextures/transparent",
	"gui/GroundCombat/small/stats_selected",
	"gui/GroundCombat/small/stats_selected",
};

soldier_inv_graphics = 
{
	"uitextures/transparent",
	"gui/GroundCombat/small/backpack_selected",
	"gui/GroundCombat/small/backpack_selected",
};

primary_wep_graphics = 
{
	"gui/GroundCombat/small/background_2handed",
	"gui/GroundCombat/small/background_2handed_selected",
	"gui/GroundCombat/small/background_2handed_selected"
};

first_weapon_graphics =
{
	"uitextures/transparent",
	"gui/GroundCombat/small/primary_selected",
	"gui/GroundCombat/small/primary_selected"
};

second_weapon_graphics =
{
	"uitextures/transparent",
	"gui/GroundCombat/small/secondary_selected",
	"gui/GroundCombat/small/secondary_selected"
};

fire_mode_graphics = 
{
	"gui/GroundCombat/small/firemode_unselected",
	"gui/GroundCombat/small/firemode_selected",
	"gui/GroundCombat/small/firemode_selected"
};

reload_weapon_graphics = 
{
	"gui/GroundCombat/small/reload_unselected",
	"gui/GroundCombat/small/reload_selected",
	"gui/GroundCombat/small/reload_selected"
};

end_turn_graphics = 
{
	"uitextures/transparent",
	"gui/GroundCombat/small/endturn_pressed",
	"gui/GroundCombat/small/endturn_pressed",
};

crouch_graphics = 
{
	"uitextures/transparent",
	"gui/GroundCombat/small/crouch_selected",
	"gui/GroundCombat/small/crouch_selected",
};

cameralevel_graphics =
{
	"gui/GroundCombat/small/cameralevel_inactive",
	"gui/GroundCombat/small/cameralevel_active",
	"gui/GroundCombat/small/cameralevel_active"
};

camerazoomout_graphics = 
{
	"gui/GroundCombat/small/cameralevelbottombutton",
	"gui/GroundCombat/small/cameralevelbottombutton_active",
	"gui/GroundCombat/small/cameralevelbottombutton_active"
};

camerazoomin_graphics = 
{
	"gui/GroundCombat/small/cameraleveltopbutton",
	"gui/GroundCombat/small/cameraleveltopbutton_active",
	"gui/GroundCombat/small/cameraleveltopbutton_active"
};

alien_alert_graphics = 
{
	"gui/GroundCombat/small/alien_visible",
	"gui/GroundCombat/small/alien_visible_mouseover",
	"gui/GroundCombat/small/alien_visible_mouseover"
};

alien_alert_notinlos_graphics = 
{
	"gui/GroundCombat/small/alien_notvisible",
	"gui/GroundCombat/small/alien_notvisible_mouseover",
	"gui/GroundCombat/small/alien_notvisible_mouseover"
};

infowidget_graphics = 
{
	"gui/GroundCombat/small/infowidget",
	"gui/GroundCombat/small/infowidget", --active?
	"gui/GroundCombat/small/infowidget", --active?
};

infowidget_vehicle_graphics = 
{
	"gui/GroundCombat/small/infowidget",
	"gui/GroundCombat/small/infowidget",
	"gui/GroundCombat/small/infowidget",
};

top_central_buttons_graphics =
{ 
	"uitextures/transparent",
	"gui/GroundCombat/small/centraltop_button_active",
	"gui/GroundCombat/small/centraltop_button_active"
};

bottom_central_buttons_graphics =
{ 
	"uitextures/transparent",
	"gui/GroundCombat/small/centralbottom_button_active",
	"gui/GroundCombat/small/centralbottom_button_active"
};

ap_slider_graphics =
{
	"gui/GroundCombat/small/reserveslider_button",
	"gui/GroundCombat/small/reserveslider_button",
	"gui/GroundCombat/small/reserveslider_button"
};


grenade_button_graphics =
{ 
	"gui/GroundCombat/small/grenade_button",
	"gui/GroundCombat/small/grenade_button_active",
	"gui/GroundCombat/small/grenade_button_active"
};

WhiteColor        = Color(255,255,255,255);
RedColor          = Color(237,27,36,255);
GreenColor        = Color(142,198,63,255);
BlueColor         = Color(0,173,239,255);
GrayColor         = Color(64,64,64,255);
OrangeColor       = Color(255,198,0,255);
TrasparentColor   = Color(0,0,0,0);
XenonautsFontName = "fonts/xenonauts.mvec";

BarColor1 = Color(237,27,36,255);
BarColor2 = Color(142,198,63,255);
BarColor3 = Color(0,173,239,255);
SInfoBarImage = "uitextures/progressbar_fill";

XenonautsDefaultFont =
{
	XenonautsFontName,
	13,
	WhiteColor
};
XenonautsDisabledFont = 
{
  XenonautsFontName,
  0,
  WhiteColor
};

ReserveButtonStyle = {
	parent   = DefaultStyle,
	font     = XenonautsDefaultFont,
	sound    = kDefaultButtonSound,
	type     = kPush,
	graphics = ap_slider_graphics,
};

local alien_alert_btn_width = 32;
local alien_alert_btn_height = 40;
local alien_alert_btn_offset = 16;
local alien_alert_btn_left = kMax - alien_alert_btn_width - alien_alert_btn_offset;

local gui_background_width = 890;
local gui_background_height = 122;
local gui_background_bottom = kMax - 20;
local gui_background_top = gui_background_bottom - gui_background_height;

local unit_info_left = kCenter + 130;
local unit_info_top = gui_background_top + 13;
local unit_info_scale_x = 1.7; 
local unit_info_scale_y = 1.25;

local unit_portrait_top = gui_background_top + 15;
local unit_portrait_left = kCenter + 34;
local unit_portrait_width = 78;
local unit_portrait_height = 96;

local crouch_width = 58;
local crouch_height = 38;
local crouch_left = kCenter + 117;
local crouch_top = gui_background_top + 75;

local soldier_inv_width = 58;
local soldier_inv_height = 38;
local soldier_inv_left = kCenter + 178;
local soldier_inv_top = crouch_top;

local soldier_stats_width = 59;
local soldier_stats_height = 38;
local soldier_stats_left = kCenter + 240;
local soldier_stats_top = crouch_top;

local snap_reserve_width = 96;
local snap_reserve_height = 26;
local no_reserve_height = 26;
local auto_reserve_height = 26;
local aimed_reserve_height = 26;
local aimed_reserve_top = gui_background_bottom - aimed_reserve_height - 2;
local auto_reserve_top = aimed_reserve_top - auto_reserve_height;
local snap_reserve_top = auto_reserve_top - snap_reserve_height;
local no_reserve_top = snap_reserve_top - no_reserve_height;
local snap_reserve_left = soldier_stats_left - soldier_stats_width / 2 - snap_reserve_width / 2;

local fire_mode_width = 30;
local fire_mode_height = 22;
local fire_mode_top = gui_background_bottom - fire_mode_height - 12;
local fire_mode_left = kCenter - 289;
local fire_mode_spacing = 1;

local reload_weapon_width = 42;
local reload_weapon_height = 22;
local reload_weapon_left = fire_mode_left + (fire_mode_width + fire_mode_spacing) + (reload_weapon_width + fire_mode_spacing) - 7;
local reload_weapon_top = fire_mode_top;

local primary_wep_btn_width = 249;
local primary_wep_btn_height = 119;
local primary_wep_btn_left = kCenter - 194;
local primary_wep_btn_top = gui_background_top + 3;

local primary_wep_clip_size_width = 60;
local primary_wep_clip_size_left = primary_wep_btn_left - 78;
local primary_wep_clip_size_top = primary_wep_btn_top + 13;

local end_turn_left = kCenter + 400;
local end_turn_top = gui_background_top + 11;

local cameralevel_width = 50;
local cameralevel_height = 12;

local camerazoomin_width = 50;
local camerazoomin_height = 12;
local camerazoomin_left = kCenter + 319;
local camerazoomin_top = gui_background_top + 13; 

local camerazoomout_width = 50;
local camerazoomout_height = 12;
local camerazoomout_left = camerazoomin_left;
local camerazoomout_top = camerazoomin_top + (camerazoomin_height + 1) + (cameralevel_height+1)*6;

local apreserve_slider_initx = kCenter - 393;
local apreserve_slider_inity = gui_background_top + 40;
local apreserve_slider_step = 14.5;
local apreserve_slider_width = 20;
local apreserve_slider_height = 15;

local infobar_height = 20;
local infobar_width = 55;
local infobar_init_x = kCenter - gui_background_width/2 + 55;
local infobar_top = gui_background_top - infobar_height;
local infobar_spacing = -3;
local soldier_infobars_image = "uitextures/progressbar_fill"; 

local miniprogressbar_width = infobar_width-25;
local miniprogressbar_height = 4;
local miniprogressbar_top = infobar_top + 4;
local miniprogressbar_left = 6;
local miniprogressbar_vspacing = 3;

local infobar_vehicle_left = infobar_init_x + (infobar_width+infobar_spacing)*13;
local infobar_vehicle_width = 55;

local vehiclebar_width = infobar_vehicle_width-25;
local vehiclebar_height = 5;
local vehiclebar_left = 6;
local vehiclebar_vspacing = 4;
local vehiclebar_top = infobar_top + 5;

local miniPortrait_width = 44;
local miniPortrait_height = 49;
local miniPortrait_hspacing = (infobar_width - miniPortrait_width) / 2 - 5;


local two_weapons_width = 108;
local first_weapon_left = primary_wep_btn_left - 58;
local second_weapon_left = primary_wep_btn_left + 60;
local two_weapons_top = primary_wep_btn_top + 10;

local cbutton_width = 39; 
local cbutton_height = 50;
local cbutton_top = gui_background_top + 10;
local cbutton_left = kCenter - 44;

local grenadebutton_width = 35;
local grenadebutton_height = 43;

local secondary_wep_btn_width = 108;
local secondary_wep_btn_height = 101;
local secondary_wep_btn_left = second_weapon_left - 1;
local secondary_wep_btn_top = two_weapons_top;

local secondary_wep_clip_size_width = 60;
local secondary_wep_clip_size_left = secondary_wep_btn_left + secondary_wep_btn_width / 2
										- secondary_wep_btn_width + secondary_wep_clip_size_width / 2 + 4;
local secondary_wep_clip_size_top = primary_wep_clip_size_top;

MakeDialog
{
	name="combatWindow",
	GameWindow
	{
		x = 0,
		y = 0,
		w = kMax,
		h = kMax,
		name="combatguiexport",


		Button
		{
			x		 = alien_alert_btn_left,
			y		 = alien_alert_btn_offset + (alien_alert_btn_height + alien_alert_btn_offset) * 0,
			name	 = "alien_alert_8",
			label	 = "alien_alert_8",
			graphics = alien_alert_graphics,
			command =
				function()
					GUIEventHandler("alien_alert_8", 1);
				end,
		},
		
		Button
		{
			x		 = alien_alert_btn_left,
			y		 = alien_alert_btn_offset + (alien_alert_btn_height + alien_alert_btn_offset) * 1,
			name	 = "alien_alert_7",
			label	 = "alien_alert_7",
			graphics = alien_alert_graphics,
			command =
				function()
					GUIEventHandler("alien_alert_7", 1);
				end,
		},
		
		Button
		{
			x		 = alien_alert_btn_left,
			y		 = alien_alert_btn_offset + (alien_alert_btn_height + alien_alert_btn_offset) * 2,
			name	 = "alien_alert_6",
			label	 = "alien_alert_6",
			graphics = alien_alert_graphics,
			command =
				function()
					GUIEventHandler("alien_alert_6", 1);
				end,
		},
		
		Button
		{
			x		 = alien_alert_btn_left,
			y		 = alien_alert_btn_offset + (alien_alert_btn_height + alien_alert_btn_offset) * 3,
			name	 = "alien_alert_5",
			label	 = "alien_alert_5",
			graphics = alien_alert_graphics,
			command =
				function()
					GUIEventHandler("alien_alert_5", 1);
				end,
		},
				
		Button
		{
			x		 = alien_alert_btn_left,
			y		 = alien_alert_btn_offset + (alien_alert_btn_height + alien_alert_btn_offset) * 4,
			name	 = "alien_alert_4",
			label	 = "alien_alert_4",
			graphics = alien_alert_graphics,
			command =
				function()
					GUIEventHandler("alien_alert_4", 1);
				end,
		},
		
		Button
		{
			x		 = alien_alert_btn_left,
			y		 = alien_alert_btn_offset + (alien_alert_btn_height + alien_alert_btn_offset) * 5,
			name	 = "alien_alert_3",
			label	 = "alien_alert_3",
			graphics = alien_alert_graphics,
			command =
				function()
					GUIEventHandler("alien_alert_3", 1);
				end,
		},
				
		Button
		{
			x		 = alien_alert_btn_left,
			y		 = alien_alert_btn_offset + (alien_alert_btn_height + alien_alert_btn_offset) * 6,
			name	 = "alien_alert_2",
			label	 = "alien_alert_2",
			graphics = alien_alert_graphics,
			command =
				function()
					GUIEventHandler("alien_alert_2", 1);
				end,
		},
		
		Button
		{
			x		 = alien_alert_btn_left,
			y		 = alien_alert_btn_offset + (alien_alert_btn_height + alien_alert_btn_offset) * 7,
			name	 = "alien_alert_1",
			label	 = "alien_alert_1",
			graphics = alien_alert_graphics,
			command =
				function()
					GUIEventHandler("alien_alert_1", 1);
				end,
		},
		
		Button
		{
			x		 = alien_alert_btn_left,
			y		 = alien_alert_btn_offset + (alien_alert_btn_height + alien_alert_btn_offset) * 0,
			name	 = "alien_alert_notinlos_8",
			label	 = "alien_alert_notinlos_8",
			graphics = alien_alert_notinlos_graphics,
			command =
				function()
					GUIEventHandler("alien_alert_8", 1);
				end,
		},
		
		Button
		{
			x		 = alien_alert_btn_left,
			y		 = alien_alert_btn_offset + (alien_alert_btn_height + alien_alert_btn_offset) * 1,
			name	 = "alien_alert_notinlos_7",
			label	 = "alien_alert_notinlos_7",
			graphics = alien_alert_notinlos_graphics,
			command =
				function()
					GUIEventHandler("alien_alert_7", 1);
				end,
		},
		
		Button
		{
			x		 = alien_alert_btn_left,
			y		 = alien_alert_btn_offset + (alien_alert_btn_height + alien_alert_btn_offset) * 2,
			name	 = "alien_alert_notinlos_6",
			label	 = "alien_alert_notinlos_6",
			graphics = alien_alert_notinlos_graphics,
			command =
				function()
					GUIEventHandler("alien_alert_6", 1);
				end,
		},
		
		Button
		{
			x		 = alien_alert_btn_left,
			y		 = alien_alert_btn_offset + (alien_alert_btn_height + alien_alert_btn_offset) * 3,
			name	 = "alien_alert_notinlos_5",
			label	 = "alien_alert_notinlos_5",
			graphics = alien_alert_notinlos_graphics,
			command =
				function()
					GUIEventHandler("alien_alert_5", 1);
				end,
		},
				
		Button
		{
			x		 = alien_alert_btn_left,
			y		 = alien_alert_btn_offset + (alien_alert_btn_height + alien_alert_btn_offset) * 4,
			name	 = "alien_alert_notinlos_4",
			label	 = "alien_alert_notinlos_4",
			graphics = alien_alert_notinlos_graphics,
			command =
				function()
					GUIEventHandler("alien_alert_4", 1);
				end,
		},
		
		Button
		{
			x		 = alien_alert_btn_left,
			y		 = alien_alert_btn_offset + (alien_alert_btn_height + alien_alert_btn_offset) * 5,
			name	 = "alien_alert_notinlos_3",
			label	 = "alien_alert_notinlos_3",
			graphics = alien_alert_notinlos_graphics,
			command =
				function()
					GUIEventHandler("alien_alert_3", 1);
				end,
		},
				
		Button
		{
			x		 = alien_alert_btn_left,
			y		 = alien_alert_btn_offset + (alien_alert_btn_height + alien_alert_btn_offset) * 6,
			name	 = "alien_alert_notinlos_2",
			label	 = "alien_alert_notinlos_2",
			graphics = alien_alert_notinlos_graphics,
			command =
				function()
					GUIEventHandler("alien_alert_2", 1);
				end,
		},
		
		Button
		{
			x		 = alien_alert_btn_left,
			y		 = alien_alert_btn_offset + (alien_alert_btn_height + alien_alert_btn_offset) * 7,
			name	 = "alien_alert_notinlos_1",
			label	 = "alien_alert_notinlos_1",
			graphics = alien_alert_notinlos_graphics,
			command =
				function()
					GUIEventHandler("alien_alert_1", 1);
				end,
		},
		
		--------------------------
		-- Some game parameters --
		--------------------------
		
		-- Pathfinding
		
		wallsOnTheWayMode = 0,		-- Meaning: 0 - turned off; 1 - "count" mode, walls are checked after a unit has passed <count> tiles; 2 - "per cent" mode, walls are checked after a unit has passed <%> of tiles which he saw at the last path finding/refreshing.
		wallsOnTheWayCount = 5,
		wallsOnTheWayPercent = 60,
	--},
	

		MainMenu
		{
			x=0,
			y=0,
			w=kMax,
			h=kMax,
		
			smallGUI = true, --this is the small gui, for screen resolutions with width <1680pixels
		
			---------------------------------
			-- Soldier toggle buttons --
			---------------------------------
	
			SetStyle( DefaultStyle ),

			BeginGroup(),
			UnitToggleButton
			{
				x		 = infobar_init_x,
				y		 = infobar_top,
				name	 = "soldier1",
				label	 = "soldier1",
				graphics = infowidget_graphics,
				type	 = kRadio,
				
				command =
					function()
						GUIEventHandler("soldier1", 1);
					end,
			},
			UnitToggleButton
			{
				x		 = infobar_init_x + (infobar_width+infobar_spacing)*1,
				y		 = infobar_top,
				name	 = "soldier2",
				label	 = "soldier2",
				graphics = infowidget_graphics,
				type	 = kRadio,
				
				command =
					function()
						GUIEventHandler("soldier2", 1);
					end,
			},
			UnitToggleButton
			{
				x		 = infobar_init_x + (infobar_width+infobar_spacing)*2,
				y		 = infobar_top,
				name	 = "soldier3",
				label	 = "soldier3",
				graphics = infowidget_graphics,
				type	 = kRadio,
				
				command =
					function()
						GUIEventHandler("soldier3", 1);
					end,
			},
			UnitToggleButton
			{
				x		 = infobar_init_x + (infobar_width+infobar_spacing)*3,
				y		 = infobar_top,
				name	 = "soldier4",
				label	 = "soldier4",
				graphics = infowidget_graphics,
				type	 = kRadio,
				
				command =
					function()
						GUIEventHandler("soldier4", 1);
					end,
			},
			UnitToggleButton
			{
				x		 = infobar_init_x + (infobar_width+infobar_spacing)*4,
				y		 = infobar_top,
				name	 = "soldier5",
				label	 = "soldier5",
				graphics = infowidget_graphics,
				type	 = kRadio,
				
				command =
					function()
						GUIEventHandler("soldier5", 1);
					end,
			},
			UnitToggleButton
			{
				x		 = infobar_init_x + (infobar_width+infobar_spacing)*5,
				y		 = infobar_top,
				name	 = "soldier6",
				label	 = "soldier6",
				graphics = infowidget_graphics,
				type	 = kRadio,
				
				command =
					function()
						GUIEventHandler("soldier6", 1);
					end,
			},
			UnitToggleButton
			{
				x		 = infobar_init_x + (infobar_width+infobar_spacing)*6,
				y		 = infobar_top,
				name	 = "soldier7",
				label	 = "soldier7",
				graphics = infowidget_graphics,
				type	 = kRadio,
				
				command =
					function()
						GUIEventHandler("soldier7", 1);
					end,
			},
			UnitToggleButton
			{
				x		 = infobar_init_x + (infobar_width+infobar_spacing)*7,
				y		 = infobar_top,
				name	 = "soldier8",
				label	 = "soldier8",
				graphics = infowidget_graphics,
				type	 = kRadio,
				
				command =
					function()
						GUIEventHandler("soldier8", 1);
					end,
			},
			UnitToggleButton
			{
				x		 = infobar_init_x + (infobar_width+infobar_spacing)*8,
				y		 = infobar_top,
				name	 = "soldier9",
				label	 = "soldier9",
				graphics = infowidget_graphics,
				type	 = kRadio,
				
				command =
					function()
						GUIEventHandler("soldier9", 1);
					end,
			},
			UnitToggleButton
			{
				x		 = infobar_init_x + (infobar_width+infobar_spacing)*9,
				y		 = infobar_top,
				name	 = "soldier10",
				label	 = "soldier10",
				graphics = infowidget_graphics,
				type	 = kRadio,
				
				command =
					function()
						GUIEventHandler("soldier10", 1);
					end,
			},
			UnitToggleButton
			{
				x		 = infobar_init_x + (infobar_width+infobar_spacing)*10,
				y		 = infobar_top,
				name	 = "soldier11",
				label	 = "soldier11",
				graphics = infowidget_graphics,
				type	 = kRadio,
				
				command =
					function()
						GUIEventHandler("soldier11", 1);
					end,
			},
			UnitToggleButton
			{
				x		 = infobar_init_x + (infobar_width+infobar_spacing)*11,
				y		 = infobar_top,
				name	 = "soldier12",
				label	 = "soldier12",
				graphics = infowidget_graphics,
				type	 = kRadio,
				
				command =
					function()
						GUIEventHandler("soldier12", 1);
					end,
			},
			UnitToggleButton
			{
				x		 = infobar_init_x + (infobar_width+infobar_spacing)*12,
				y		 = infobar_top,
				name	 = "soldier13",
				label	 = "soldier13",
				graphics = infowidget_graphics,
				type	 = kRadio,
				
				command =
					function()
						GUIEventHandler("soldier13", 1);
					end,
			},
			UnitToggleButton
			{
				x		 = infobar_init_x + (infobar_width+infobar_spacing)*13,
				y		 = infobar_top,
				name	 = "soldier14",
				label	 = "soldier14",
				graphics = infowidget_graphics,
				type	 = kRadio,
				
				command =
					function()
						GUIEventHandler("soldier14", 1);
					end,
			},
			UnitToggleButton
			{
				x		 = infobar_init_x + (infobar_width+infobar_spacing)*14,
				y		 = infobar_top,
				name	 = "soldier15",
				label	 = "soldier15",
				graphics = infowidget_graphics,
				type	 = kRadio,
				
				command =
					function()
						GUIEventHandler("soldier15", 1);
					end,
			},
			UnitToggleButton
			{
				x		 = infobar_init_x + (infobar_width+infobar_spacing)*15,
				y		 = infobar_top,
				name	 = "soldier16",
				label	 = "soldier16",
				graphics = infowidget_graphics,
				type	 = kRadio,
				
				command =
					function()
						GUIEventHandler("soldier16", 1);
					end,
			},
			
			BeginGroup(),
			
			--------------------------------
			-- Soldier toggle buttons end --
			--------------------------------

			---------------------
			-- Vehicle buttons --
			---------------------
			
			Button
			{
				x=infobar_vehicle_left + (infobar_vehicle_width + infobar_spacing)*0,
				y=infobar_top,
				name="vehicle1",
				label="vehicle1",
				graphics=infowidget_vehicle_graphics,
				type=kRadio,
				command=function() GUIEventHandler("vehicle1", 1); end,
			},
			Button
			{
				x=infobar_vehicle_left + (infobar_vehicle_width + infobar_spacing)*1,
				y=infobar_top,
				name="vehicle2",
				label="vehicle2",
				graphics=infowidget_vehicle_graphics,
				type=kRadio,
				command=function() GUIEventHandler("vehicle2", 1); end,
			},
			Button
			{
				x= infobar_vehicle_left + (infobar_vehicle_width + infobar_spacing)*2,
				y=infobar_top,
				name="vehicle3",
				label="vehicle3",
				graphics=infowidget_vehicle_graphics,
				type=kRadio,
				command=function() GUIEventHandler("vehicle3", 1); end,
			},
			
			BeginGroup(),
			
			-------------------------
			-- Vehicle buttons end --
			-------------------------
			
			Bitmap
			{
				name="gui_background",
				image="gui/GroundCombat/small/background",
				x = kCenter,
				y = gui_background_top,
			},
			
			------------------
			-- Vehicle bars --
			------------------
			
			ScalingText --vehicle1
		    {
			  font = XenonautsDefaultFont,
			  name = "vehicle1_number",
			  x = infobar_vehicle_left + (infobar_vehicle_width + infobar_spacing)*0 + 10,
			  y = infobar_top + 3,
			  w = infobar_width,
			  h = infobar_height,
			  label = "#1",
			  fontScale = 1.0,
			},
			ProgressBar
			{
			  font = XenonautsDisabledFont,
			  name = "vehicle1_hpbar",
			  x = infobar_vehicle_left + (infobar_vehicle_width + infobar_spacing)*0 + vehiclebar_left,
			  y = vehiclebar_top,
			  w = vehiclebar_width,
			  h = vehiclebar_height,
			  barheight = vehiclebar_height,
			  min = 0,
			  max = 100,
			  barcolor = RedColor,
			  barcolor2 = TrasparentColor,
			  barimage = soldier_infobars_image,
			  percent  = false,
			},
			ProgressBar
			{
			  font = XenonautsDisabledFont,
			  name = "vehicle1_apbar",
			  x = infobar_vehicle_left + (infobar_vehicle_width + infobar_spacing)*0 + vehiclebar_left,
			  y = vehiclebar_top + vehiclebar_vspacing*1,
			  w = vehiclebar_width,
			  h = vehiclebar_height,
			  barheight = vehiclebar_height,
			  min = 0,
			  max = 100,
			  barcolor = OrangeColor,
			  barcolor2 = GreenColor,
			  barimage = soldier_infobars_image,
			  percent  = false,
			},
			ScalingText --vehicle2
		    {
			  font = XenonautsDefaultFont,
			  name = "vehicle2_number",
			  x = infobar_vehicle_left + (infobar_vehicle_width + infobar_spacing)*1 + 8,
			  y = infobar_top + 3,
			  w = infobar_width,
			  h = infobar_height,
			  label = "#2",
			  fontScale = 1.0,
			},
			ProgressBar
			{
			  font = XenonautsDisabledFont,
			  name = "vehicle2_hpbar",
			  x = infobar_vehicle_left + (infobar_vehicle_width + infobar_spacing)*1 + vehiclebar_left,
			  y = vehiclebar_top,
			  w = vehiclebar_width,
			  h = vehiclebar_height,
			  barheight = vehiclebar_height,
			  min = 0,
			  max = 100,
			  barcolor = RedColor,
			  barcolor2 = TrasparentColor,
			  barimage = soldier_infobars_image,
			  percent  = false,
			},
			ProgressBar
			{
			  font = XenonautsDisabledFont,
			  name = "vehicle2_apbar",
			  x = infobar_vehicle_left + (infobar_vehicle_width + infobar_spacing)*1 + vehiclebar_left,
			  y = vehiclebar_top + vehiclebar_vspacing*1,
			  w = vehiclebar_width,
			  h = vehiclebar_height,
			  barheight = vehiclebar_height,
			  min = 0,
			  max = 100,
			  barcolor = OrangeColor,
			  barcolor2 = GreenColor,
			  barimage = soldier_infobars_image,
			  percent  = false,
			},
			ScalingText --vehicle3
		    {
			  font = XenonautsDefaultFont,
			  name = "vehicle3_number",
			  x = infobar_vehicle_left + (infobar_vehicle_width + infobar_spacing)*2 + 8,
			  y = infobar_top + 3,
			  w = infobar_width,
			  h = infobar_height,
			  label = "#3",
			  fontScale = 1.0,
			},
			ProgressBar
			{
			  font = XenonautsDisabledFont,
			  name = "vehicle3_hpbar",
			  x = infobar_vehicle_left + (infobar_vehicle_width + infobar_spacing)*2 + vehiclebar_left,
			  y = vehiclebar_top,
			  w = vehiclebar_width,
			  h = vehiclebar_height,
			  barheight = vehiclebar_height,
			  min = 0,
			  max = 100,
			  barcolor = RedColor,
			  barcolor2 = TrasparentColor,
			  barimage = soldier_infobars_image,
			  percent  = false,
			},
			ProgressBar
			{
			  font = XenonautsDisabledFont,
			  name = "vehicle3_apbar",
			  x = infobar_vehicle_left + (infobar_vehicle_width + infobar_spacing)*2 + vehiclebar_left,
			  y = vehiclebar_top + vehiclebar_vspacing*1,
			  w = vehiclebar_width,
			  h = vehiclebar_height,
			  barheight = vehiclebar_height,
			  min = 0,
			  max = 100,
			  barcolor = OrangeColor,
			  barcolor2 = GreenColor,
			  barimage = soldier_infobars_image,
			  percent  = false,
			},

			------------------------
			-- Toggle Roof button --
			------------------------
			--Toggle Roof replacing the Stats button
			Button
			{
				x		 = soldier_stats_left,
				y		 = soldier_stats_top,
				name	 = "toggle_roof",
				--label	 = "soldier_stats",
				graphics = soldier_stats_graphics,

				command =
					function()
						GUIEventHandler("toggle_roof", 1);
					end,
			},
			Bitmap
			{
			  name="rooftoggle_off",
			  image="gui/GroundCombat/small/rooftoggle_off",
			  x = soldier_stats_left,
			  y = soldier_stats_top,
			},
			Bitmap
			{
			  name="rooftoggle_on",
			  image="gui/GroundCombat/small/rooftoggle_on",
			  x = soldier_stats_left,
			  y = soldier_stats_top,
			},
			Bitmap
			{
			  name="rooftoggle_ground",
			  image="gui/GroundCombat/small/rooftoggle_ground",
			  x = soldier_stats_left,
			  y = soldier_stats_top,
			},
			TooltipRect
			{
				x = soldier_stats_left,
				y = soldier_stats_top,
				w = soldier_stats_width,
				h = soldier_stats_height,
				
				text="GcGUI.Tooltips.ToggleRoof",
				uppercase = false,
			},
			
			-------------------
			-- Crouch button --
			-------------------
			
			Button
			{
				x		 = crouch_left,
				y		 = crouch_top,
				name	 = "crouch",
				label	 = "crouch",
				graphics = crouch_graphics,
				
				command =
					function()
						GUIEventHandler("crouch", 1);
					end,
			},
			
			Bitmap
			{
			  name="crouchtoggle_on",
			  image="gui/GroundCombat/small/crouchtoggle_on",
			  x = crouch_left,
			  y = crouch_top,
			},
			Bitmap
			{
			  name="crouchtoggle_off",
			  image="gui/GroundCombat/small/crouchtoggle_off",
			  x = crouch_left,
			  y = crouch_top,
			},
			TooltipRect
			{
				x = crouch_left,
				y = crouch_top,
				w = crouch_width,
				h = crouch_height,
				
				text="GcGUI.Tooltips.CrouchToggle",
				uppercase = false,
			},
			
			---------------------------------
			-- Soldier Stats & Inv buttons --
			---------------------------------
			--[[Button
			{
				x		 = soldier_stats_left,
				y		 = soldier_stats_top,
				name	 = "soldier_stats",
				label	 = "soldier_stats",
				graphics = soldier_stats_graphics,

				command =
					function()
						GUIEventHandler("soldier_stats", 1);
					end,
			},
			ScalingText
		    {
			  font = XenonautsDefaultFont,
			  name = "stats",
			  x = soldier_stats_left,
			  y = soldier_stats_top,
			  w = soldier_stats_width,
			  h = soldier_stats_height,
  			  flags = kHAlignCenter + kVAlignCenter,
			  label = "#STATS",
			  fontScale = 1.3,
		    },
			TooltipRect
			{
				x = soldier_stats_left,
				y = soldier_stats_top,
				w = soldier_stats_width,
				h = soldier_stats_height,
				
				text="GcGUI.Tooltips.SoldierStatistics",
				uppercase = false,
			},]]--
			
			Button
			{
				x		 = soldier_inv_left,
				y		 = soldier_inv_top,
				name	 = "soldier_inv",
				label	 = "soldier_inv",
				graphics = soldier_inv_graphics,

				command =
					function()
						GUIEventHandler("soldier_inv", 1);
					end,
			},
			Bitmap
			{
			  name="inventory_icon",
			  image="gui/GroundCombat/small/inventory_icon",
			  x = soldier_inv_left,
			  y = soldier_inv_top,
			},
			TooltipRect
			{
				x = soldier_inv_left,
				y = soldier_inv_top,
				w = soldier_inv_width,
				h = soldier_inv_height,
				
				text="GcGUI.Tooltips.SoldierInventory",
				uppercase = false,
			},
			
		------------------
		-- Soldier info --		
		------------------
	    
		TooltipRect
		{
			x = unit_info_left + Floor( ( 80 * 0.9 ) * unit_info_scale_y ),
			y = unit_info_top,
			w = 160 * unit_info_scale_x - Floor( ( 80 * 0.9 ) * unit_info_scale_y ),
			h = soldier_inv_top - gui_background_top - 10,
			
			text="GcGUI.Tooltips.SoldierInformationPanel",
			uppercase = false,
		},
			
		TiledImage
		{
		
		  name = "soldierinfobg",
		  x = unit_info_left,
		  y = unit_info_top,
		  w = 160 * unit_info_scale_x,
		  h = 80 * unit_info_scale_y,
		  image = "uitextures/transparent",
		  bordersize = 2,
		  
		  NonUniformScaledImage
		  {
			name = "soldierflag",
			x = Floor( ( 80 * 0.9 ) * unit_info_scale_y ) + 5,
			y = Floor (4 * unit_info_scale_y),
			w = 13,
			h = 13,
			image = "gui/flags/latvia",
		  },
	      
		  ScalingText
		  {
			font = XenonautsDefaultFont,
			name = "soldiername",
			x = Floor( ( 80 * 0.9 ) * unit_info_scale_y ) + Floor( 9 * unit_info_scale_y ) + 8,
			y = 4,
			w = kMax - 2,
			h = 12 * unit_info_scale_y,
  			flags = kVAlignCenter,
			label = "#CPL. Jack Longname",
			fontScale = 1.0, 
		  },

		  NonUniformScaledImage
		  {
			x = Floor( ( 80 * 0.9 ) * unit_info_scale_y ) + 6,
			y = Floor( 18 * unit_info_scale_y ),
			w = 10,
			h = 7,
			image = "gui/GroundCombat/small/heart",
		  },
		  ProgressBar
		  {
			font = XenonautsDisabledFont,
			name = "hpbar",
			x = Floor( ( 80 * 0.9 ) * unit_info_scale_y ) + Floor( 9 * unit_info_scale_y ) + 8,
			y = Floor( 16 * unit_info_scale_y ),
			w = kMax - 22 * unit_info_scale_x,
			h = Floor( 8 * unit_info_scale_y ),
			barheight = 8 * unit_info_scale_y,
			min = 0,
			max = 100,
			barcolor = BarColor1,
			barcolor2 = GrayColor,
			bgimage  = "uitextures/progressbg",
			barimage = SInfoBarImage,
			bgtilebordersize = 1,
			percent  = false,
		  },
		  ScalingText
		  {
			font = XenonautsDefaultFont,
			name = "hpvalue",
			x = kMax - 20 * unit_info_scale_x,
			y = Floor( 16 * unit_info_scale_y ),
			w = kMax,
			h = Floor( 12 * unit_info_scale_y ),
			label = "#08/17",
			fontScale = 0.9,
		  },

		  NonUniformScaledImage
		  {
			x = Floor( ( 80 * 0.9 ) * unit_info_scale_y ) + 6,
			y = Floor( 18 * unit_info_scale_y ) + Floor( 11 * unit_info_scale_y ),
			w = 10,
			h = 7,
			image = "gui/GroundCombat/small/clock",
		  },
		  ProgressBar
		  {
			font = XenonautsDisabledFont,
			name = "apbar",
			x = Floor( ( 80 * 0.9 ) * unit_info_scale_y ) + Floor( 9 * unit_info_scale_y ) + 8,
			y = Floor( 16 * unit_info_scale_y ) + Floor( 11 * unit_info_scale_y ),
			w = kMax - 22 * unit_info_scale_x,
			h = Floor( 8 * unit_info_scale_y ),
			barheight = 8 * unit_info_scale_y,
			min = 0,
			max = 100,
			barcolor = OrangeColor,
			barcolor2 = BarColor2,
			bgimage  = "uitextures/progressbg",
			barimage = SInfoBarImage,
			bgtilebordersize = 1,
			percent  = false,
		  },
		  ScalingText
		  {
			font = XenonautsDefaultFont,
			name = "apvalue",
			x = kMax - 20 * unit_info_scale_x,
			y = Floor( 16 * unit_info_scale_y ) + Floor( 11 * unit_info_scale_y ),
			w = kMax,
			h = Floor( 12 * unit_info_scale_y ),
			label = "#08/17",
			fontScale = 0.9,
		  },

		  NonUniformScaledImage
		  {
			x = Floor( ( 80 * 0.9 ) * unit_info_scale_y ) + 6,
			y = Floor( 18 * unit_info_scale_y ) + 2 * Floor( 11 * unit_info_scale_y ),
			w = 10,
			h = 7,
			image = "gui/GroundCombat/small/flag",
		  },
		  ProgressBar
		  {
			font = XenonautsDisabledFont,
			name = "moralebar",
			x = Floor( ( 80 * 0.9 ) * unit_info_scale_y ) + Floor( 9 * unit_info_scale_y ) + 8,
			y = Floor( 16 * unit_info_scale_y ) + 2 * Floor( 11 * unit_info_scale_y ),
			w = kMax - 22 * unit_info_scale_x,
			h = Floor( 8 * unit_info_scale_y ),
			barheight = 8 * unit_info_scale_y,
			min = 0,
			max = 100,
			barcolor = BarColor3,
			barcolor2 = BarColor3,
			bgimage  = "uitextures/progressbg",
			barimage = SInfoBarImage,
			bgtilebordersize = 1,
			percent  = false,
		  },
		  ScalingText
		  {
			font = XenonautsDefaultFont,
			name = "moralevalue",
			x = kMax - 20 * unit_info_scale_x,
			y = Floor( 16 * unit_info_scale_y ) + 2*Floor( 11 * unit_info_scale_y ),
			w = kMax,
			h = Floor( 12 * unit_info_scale_y ),
			label = "#08/17",
			fontScale = 0.9,
		  },
		},
		-- Put "+" for morale as a separate label because (1) there is no place in "soldierinfobg"
		-- for it (2) we need it in bigger font since "moralevalue" font makes very small "+".
	    ScalingText
	    {
	      font = XenonautsDefaultFont,
	      name = "moralevalue_limiter",
	      x = unit_info_left + 80 * unit_info_scale_x,
	      y = unit_info_top + Floor( 16 * unit_info_scale_y ) + 2*Floor( 11 * unit_info_scale_y ) - 3,
	      w = 5 * unit_info_scale_x,
	      h = Floor( 16 * unit_info_scale_y ),
	      label = "#+",
	      fontScale = 1.4,
	    },
		
		Button
		{
			x = unit_portrait_left,
			y = unit_portrait_top,
			w = unit_portrait_width,
			h = unit_portrait_height,
			command =
				function()
					GUIEventHandler("centeronsoldier", 1);
				end,

		TiledImage
		  {
			x = 0,
			y = 0,
			w = unit_portrait_width,
			h = unit_portrait_height,
			image = "uitextures/transparent",
			bordersize = 0,
			
	        TooltipRect
			{
				x = 0,
				y = 1,
				w = kMax,
				h = kMax,
				
				text="GcGUI.Tooltips.SoldierPortrait",
				uppercase = false,
			},
			NonUniformScaledImage
			{
			  name = "soldierImage",
			  x = -6,
			  y = 0,
			  w = 90,
			  h = 100,
			  image = "soldierimages/face1",
			  bordersize = 0,
			  
			  NonUniformScaledImage
			  {
				name = "bleedingWoundsIcon",
				x = kMax - 36,
				y = 0,
				w = 36,
				h = 36,
				image = "tiles/bleeding_icon",
				bordersize = 0,
			  },
			},  
			NonUniformScaledImage
			{
			  name = "soldierRankImage",
			  x = kMax - 26,
			  y = kMax - 28,
			  w = 26,
			  h = 26,
			  image = "rankimages/GroundCombat/private",
			  aspectfix = 1.0;
			},
			NonUniformScaledImage
			{
			  name = "soldierRoleImage",
			  x = 2,
			  y = kMax - 22,
			  w = 20,
			  h = 20,
			  --image = "uitextures/roles/unused",
			  aspectfix = 1.0;
			},
			NonUniformScaledImage
			{
			  name = "vehicleImage",
			  x = 0,
			  y = 38,
			  w = kMax,
			  h = kMax,
			  image = "soldierimages/face1",
			  aspectfix = 1.33;
			},
		    },
		  },
			
			------------------------
			-- AP Reserve control --
			------------------------
			
			TooltipRect
			{
				x = kCenter - gui_background_width/2 + 55,
				y = gui_background_top,
				w = 110,
				h = gui_background_height,
				
				text = "GcGUI.Tooltips.TUReserveSlider",
				uppercase = false,
			},
			ScalingText
		    {
			  font = XenonautsDefaultFont,
			  name = "tureserve",
			  x = apreserve_slider_initx + 15,
			  y = apreserve_slider_inity - 25,
			  w = 80,
			  h = 20,
  			  flags = kVAlignCenter,
			  label = "GcGUI.Labels.TUReserve",
			  fontScale = 1.0,
			},
			ScalingText
		    {
			  font = XenonautsDefaultFont,
			  name = "no_reserve_txt",
			  x = apreserve_slider_initx + 43,
			  y = apreserve_slider_inity,
			  w = 80,
			  h = apreserve_slider_height,
			  flags = kHAlignLeft+kVAlignCenter,
			  label = "GcGUI.Labels.NoReserve",
			  fontScale = 0.9,
			},
			ScalingText
		    {
			  font = XenonautsDefaultFont,
			  name = "snap_reserve_txt",
			  x = apreserve_slider_initx + 43,
			  y = apreserve_slider_inity + apreserve_slider_step,
			  w = 80,
			  h = apreserve_slider_height,
			  flags = kHAlignLeft+kVAlignCenter,
			  label = "GcGUI.Labels.SnapReserve",
			  fontScale = 0.9,
			},
			ScalingText
		    {
			  font = XenonautsDefaultFont,
			  name = "normal_reserve_txt",
			  x = apreserve_slider_initx + 43,
			  y = apreserve_slider_inity + apreserve_slider_step*2,
			  w = 80,
			  h = apreserve_slider_height,
			  flags = kHAlignLeft+kVAlignCenter,
			  label = "GcGUI.Labels.NormalReserve",
			  fontScale = 0.9,
			},
			ScalingText
		    {
			  font = XenonautsDefaultFont,
			  name = "aimed_reserve_txt",
			  x = apreserve_slider_initx + 43,
			  y = apreserve_slider_inity + apreserve_slider_step*3,
			  w = 80,
			  h = apreserve_slider_height,
			  flags = kHAlignLeft+kVAlignCenter,
			  label = "GcGUI.Labels.AimedReserve",
			  fontScale = 0.9,
			},
			ScalingText
		    {
			  font = XenonautsDefaultFont,
			  name = "burst_reserve_txt",
			  x = apreserve_slider_initx + 43,
			  y = apreserve_slider_inity + apreserve_slider_step*4,
			  w = 80,
			  h = apreserve_slider_height,
			  flags = kHAlignLeft+kVAlignCenter,
			  label = "GcGUI.Labels.BurstReserve",
			  fontScale = 0.9,
			},
			ScalingText
		    {
			  font = XenonautsDefaultFont,
			  name = "snap_reserve_aps",
			  x = apreserve_slider_initx - 30,
			  y = apreserve_slider_inity + apreserve_slider_step,
			  w = 18,
			  h = apreserve_slider_height,
			  flags = kHAlignLeft+kVAlignCenter,
			  label = "#14",
			  fontScale = 0.9,
			},
			ScalingText
		    {
			  font = XenonautsDefaultFont,
			  name = "normal_reserve_aps",
			  x = apreserve_slider_initx - 30,
			  y = apreserve_slider_inity + apreserve_slider_step*2,
			  w = 18,
			  h = apreserve_slider_height,
			  flags = kHAlignLeft+kVAlignCenter,
			  label = "#18",
			  fontScale = 0.9,
			},
			ScalingText
		    {
			  font = XenonautsDefaultFont,
			  name = "aimed_reserve_aps",
			  x = apreserve_slider_initx - 30,
			  y = apreserve_slider_inity + apreserve_slider_step*3,
			  w = 18,
			  h = apreserve_slider_height,
			  flags = kHAlignLeft+kVAlignCenter,
			  label = "#43",
			  fontScale = 0.9,
			},
			ScalingText
		    {
			  font = XenonautsDefaultFont,
			  name = "burst_reserve_aps",
			  x = apreserve_slider_initx - 30,
			  y = apreserve_slider_inity + apreserve_slider_step*4,
			  w = 18,
			  h = apreserve_slider_height,
			  flags = kHAlignLeft+kVAlignCenter,
			  label = "#30",
			  fontScale = 0.9,
			},
	
	SetStyle( ReserveButtonStyle ),		
			Button
			{
				name="no_reserve",
				x = apreserve_slider_initx,
				y = apreserve_slider_inity + apreserve_slider_step*0,
				
				command =
					function()
						GUIEventHandler("no_reserve", 1);
					end,
			},
			Button
			{
				name="snap_reserve",
				x = apreserve_slider_initx,
				y = apreserve_slider_inity + apreserve_slider_step*1,
				
				command =
					function()
						GUIEventHandler("snap_reserve", 1);
					end,
			},
			Button
			{
				name="normal_reserve",
				x = apreserve_slider_initx,
				y = apreserve_slider_inity + apreserve_slider_step*2,
				
				command =
					function()
					 GUIEventHandler("normal_shot_reserve", 1);
					end,
			},
			Button
			{
				name="aimed_reserve",
				x = apreserve_slider_initx,
				y = apreserve_slider_inity + apreserve_slider_step*3,
				
				command =
					function()
						GUIEventHandler("aimed_reserve", 1);
					end,
			},
			Button
			{
				name="auto_reserve",
				x = apreserve_slider_initx,
				y = apreserve_slider_inity + apreserve_slider_step*4,
				
				command =
					function()
						GUIEventHandler("auto_reserve", 1);
					end,
			},
			NonUniformScaledImage
			{
				name = "ap_reserve_slider",
				x = apreserve_slider_initx,
				y = apreserve_slider_inity,
				w = 105,
				h = 15,
				image = "gui/GroundCombat/small/reserveslider_active",
				bordersize = 0,
			},
			
			------------------------------
			-- Soldier information bars --
			------------------------------

			ScalingText --soldier1
		    {
			  font = XenonautsDefaultFont,
			  name = "soldier1_number",
			  x = infobar_init_x + 10,
			  y = infobar_top + 3,
			  w = infobar_width,
			  h = infobar_height,
			  label = "#1",
			  fontScale = 1.0,
			},
			ProgressBar
			{
			  font = XenonautsDisabledFont,
			  name = "soldier1_hpbar",
			  x = infobar_init_x + miniprogressbar_left,
			  y = miniprogressbar_top,
			  w = miniprogressbar_width,
			  h = miniprogressbar_height,
			  barheight = miniprogressbar_height,
			  min = 0,
			  max = 100,
			  barcolor = RedColor,
			  barcolor2 = TrasparentColor,
			  barimage = soldier_infobars_image,
			  percent  = false,
			},
			ProgressBar
			{
			  font = XenonautsDisabledFont,
			  name = "soldier1_apbar",
			  x = infobar_init_x + miniprogressbar_left,
			  y = miniprogressbar_top + miniprogressbar_vspacing*1,
			  w = miniprogressbar_width,
			  h = miniprogressbar_height,
			  barheight = miniprogressbar_height,
			  min = 0,
			  max = 100,
			  barcolor = OrangeColor,
			  barcolor2 = GreenColor,
			  barimage = soldier_infobars_image,
			  percent  = false,
			},
			ProgressBar
			{
			  font = XenonautsDisabledFont,
			  name = "soldier1_moralebar",
			  x = infobar_init_x + miniprogressbar_left,
			  y = miniprogressbar_top + miniprogressbar_vspacing*2,
			  w = miniprogressbar_width,
			  h = miniprogressbar_height,
			  barheight = miniprogressbar_height,
			  min = 0,
			  max = 100,
			  barcolor = BlueColor,
			  barcolor2 = TrasparentColor,
			  barimage = soldier_infobars_image,
			  percent  = false,
			},
			Window
			{
				name = "soldier1_miniPortraitPopup",
				x = infobar_init_x + miniPortrait_hspacing + (160 * unit_info_scale_x) / 2,
				y = infobar_top - miniPortrait_height,
				w = miniPortrait_width + 160 * unit_info_scale_x,  -- Image width + text labels
				h = miniPortrait_height,
				
				NonUniformScaledImage
				{
				  name = "miniPortraitFrame",
				  x = 0,
				  y = 0,
				  w = miniPortrait_width,
				  h = miniPortrait_height,
				  image = "gui/GroundCombat/small/soldier_miniPortrait",
				  bordersize = 0,
				  
				  NonUniformScaledImage
				  {
					name = "miniPortrait",
					x = 1,
					y = 1,
					w = kMax - 1,
					h = kMax - 1,
					image = "soldierimages/face1",
					bordersize = 0,
				  },
				},
				
				ScalingText
				{
				  name = "soldierName",
				  x = miniPortrait_width + 1,
				  y = 0,
				  w = 160 * unit_info_scale_x - 2,
				  h = 13,
				  label = "#CPL. Jack Longname",
				  font = XenonautsDefaultFont,
				  fontScale = 1.0,
				},
				ScalingText
				{
				  name = "soldierRole",
				  x = miniPortrait_width + 1,
				  y = 13,
				  w = 160 * unit_info_scale_x - 2,
				  h = 13,
				  label = "#Rifleman",
				  font = XenonautsDefaultFont,
				  fontScale = 1.0,
				},
				NonUniformScaledImage
				{
				  name = "soldierRoleImage",
				  x = miniPortrait_width + 3,
				  y = 27,
				  w = 20,
				  h = 20,
				  --image = "uitextures/roles/unused",
				  aspectfix = 1.0;
				},
			},

			ScalingText --soldier2
		    {
			  font = XenonautsDefaultFont,
			  name = "soldier2_number",
			  x = infobar_init_x + (infobar_width+infobar_spacing)*1 + 8,
			  y = infobar_top + 3,
			  w = infobar_width,
			  h = infobar_height,
			  label = "#2",
			  fontScale = 1.0,
			},
			ProgressBar
			{
			  font = XenonautsDisabledFont,
			  name = "soldier2_hpbar",
			  x = (infobar_init_x + miniprogressbar_left) + (infobar_width+infobar_spacing)*1,
			  y = miniprogressbar_top,
			  w = miniprogressbar_width,
			  h = miniprogressbar_height,
			  barheight = miniprogressbar_height,
			  min = 0,
			  max = 100,
			  barcolor = RedColor,
			  barcolor2 = TrasparentColor,
			  barimage = soldier_infobars_image,
			  percent  = false,
			},
			ProgressBar
			{
			  font = XenonautsDisabledFont,
			  name = "soldier2_apbar",
			 x = (infobar_init_x + miniprogressbar_left) + (infobar_width+infobar_spacing)*1,
			  y = miniprogressbar_top + miniprogressbar_vspacing*1,
			  w = miniprogressbar_width,
			  h = miniprogressbar_height,
			  barheight = miniprogressbar_height,
			  min = 0,
			  max = 100,
			  barcolor = OrangeColor,
			  barcolor2 = GreenColor,
			  barimage = soldier_infobars_image,
			  percent  = false,
			},
			ProgressBar
			{
			  font = XenonautsDisabledFont,
			  name = "soldier2_moralebar",
			  x = (infobar_init_x + miniprogressbar_left) + (infobar_width+infobar_spacing)*1,
			  y = miniprogressbar_top + miniprogressbar_vspacing*2,
			  w = miniprogressbar_width,
			  h = miniprogressbar_height,
			  barheight = miniprogressbar_height,
			  min = 0,
			  max = 100,
			  barcolor = BlueColor,
			  barcolor2 = TrasparentColor,
			  barimage = soldier_infobars_image,
			  percent  = false,
			},
			Window
			{
				name = "soldier2_miniPortraitPopup",
				x = infobar_init_x + (infobar_width+infobar_spacing)*1 + miniPortrait_hspacing + (160 * unit_info_scale_x) / 2,
				y = infobar_top - miniPortrait_height,
				w = miniPortrait_width + 160 * unit_info_scale_x,
				h = miniPortrait_height,
				
				NonUniformScaledImage
				{
				  name = "miniPortraitFrame",
				  x = 0,
				  y = 0,
				  w = miniPortrait_width,
				  h = miniPortrait_height,
				  image = "gui/GroundCombat/small/soldier_miniPortrait",
				  bordersize = 0,
				  
				  NonUniformScaledImage
				  {
					name = "miniPortrait",
					x = 1,
					y = 1,
					w = kMax - 1,
					h = kMax - 1,
					image = "soldierimages/face1",
					bordersize = 0,
				  },
				},
				
				ScalingText
				{
				  name = "soldierName",
				  x = miniPortrait_width + 1,
				  y = 0,
				  w = 160 * unit_info_scale_x - 2,
				  h = 13,
				  label = "#CPL. Jack Longname",
				  font = XenonautsDefaultFont,
				  fontScale = 1.0,
				},
				ScalingText
				{
				  name = "soldierRole",
				  x = miniPortrait_width + 1,
				  y = 13,
				  w = 160 * unit_info_scale_x - 2,
				  h = 13,
				  label = "#Rifleman",
				  font = XenonautsDefaultFont,
				  fontScale = 1.0,
				},
				NonUniformScaledImage
				{
				  name = "soldierRoleImage",
				  x = miniPortrait_width + 3,
				  y = 27,
				  w = 20,
				  h = 20,
				  --image = "uitextures/roles/unused",
				  aspectfix = 1.0;
				},
			},

			ScalingText --soldier3
		    {
			  font = XenonautsDefaultFont,
			  name = "soldier3_number",
			  x = infobar_init_x + (infobar_width+infobar_spacing)*2 + 8,
			  y = infobar_top + 3,
			  w = infobar_width,
			  h = infobar_height,
			  label = "#3",
			  fontScale = 1.0,
			},
			ProgressBar
			{
			  font = XenonautsDisabledFont,
			  name = "soldier3_hpbar",
			  x = (infobar_init_x + miniprogressbar_left) + (infobar_width+infobar_spacing)*2,
			  y = miniprogressbar_top,
			  w = miniprogressbar_width,
			  h = miniprogressbar_height,
			  barheight = miniprogressbar_height,
			  min = 0,
			  max = 100,
			  barcolor = RedColor,
			  barcolor2 = TrasparentColor,
			  barimage = soldier_infobars_image,
			  percent  = false,
			},
			ProgressBar
			{
			  font = XenonautsDisabledFont,
			  name = "soldier3_apbar",
			 x = (infobar_init_x + miniprogressbar_left) + (infobar_width+infobar_spacing)*2,
			  y = miniprogressbar_top + miniprogressbar_vspacing*1,
			  w = miniprogressbar_width,
			  h = miniprogressbar_height,
			  barheight = miniprogressbar_height,
			  min = 0,
			  max = 100,
			  barcolor = OrangeColor,
			  barcolor2 = GreenColor,
			  barimage = soldier_infobars_image,
			  percent  = false,
			},
			ProgressBar
			{
			  font = XenonautsDisabledFont,
			  name = "soldier3_moralebar",
			  x = (infobar_init_x + miniprogressbar_left) + (infobar_width+infobar_spacing)*2,
			  y = miniprogressbar_top + miniprogressbar_vspacing*2,
			  w = miniprogressbar_width,
			  h = miniprogressbar_height,
			  barheight = miniprogressbar_height,
			  min = 0,
			  max = 100,
			  barcolor = BlueColor,
			  barcolor2 = TrasparentColor,
			  barimage = soldier_infobars_image,
			  percent  = false,
			},
			Window
			{
				name = "soldier3_miniPortraitPopup",
				x = infobar_init_x + (infobar_width+infobar_spacing)*2 + miniPortrait_hspacing + (160 * unit_info_scale_x) / 2,
				y = infobar_top - miniPortrait_height,
				w = miniPortrait_width + 160 * unit_info_scale_x,
				h = miniPortrait_height,
			
				NonUniformScaledImage
				{
				  name = "miniPortraitFrame",
				  x = 0,
				  y = 0,
				  w = miniPortrait_width,
				  h = miniPortrait_height,
				  image = "gui/GroundCombat/small/soldier_miniPortrait",
				  bordersize = 0,
				  
				  NonUniformScaledImage
				  {
					name = "miniPortrait",
					x = 1,
					y = 1,
					w = kMax - 1,
					h = kMax - 1,
					image = "soldierimages/face1",
					bordersize = 0,
				  },
				},
				
				ScalingText
				{
				  name = "soldierName",
				  x = miniPortrait_width + 1,
				  y = 0,
				  w = 160 * unit_info_scale_x - 2,
				  h = 13,
				  label = "#CPL. Jack Longname",
				  font = XenonautsDefaultFont,
				  fontScale = 1.0,
				},
				ScalingText
				{
				  name = "soldierRole",
				  x = miniPortrait_width + 1,
				  y = 13,
				  w = 160 * unit_info_scale_x - 2,
				  h = 13,
				  label = "#Rifleman",
				  font = XenonautsDefaultFont,
				  fontScale = 1.0,
				},
				NonUniformScaledImage
				{
				  name = "soldierRoleImage",
				  x = miniPortrait_width + 3,
				  y = 27,
				  w = 20,
				  h = 20,
				  --image = "uitextures/roles/unused",
				  aspectfix = 1.0;
				},
			},

			ScalingText --soldier4
		    {
			  font = XenonautsDefaultFont,
			  name = "soldier4_number",
			  x = infobar_init_x + (infobar_width+infobar_spacing)*3 + 8,
			  y = infobar_top + 3,
			  w = infobar_width,
			  h = infobar_height,
			  label = "#4",
			  fontScale = 1.0,
			},
			ProgressBar
			{
			  font = XenonautsDisabledFont,
			  name = "soldier4_hpbar",
			  x = (infobar_init_x + miniprogressbar_left) + (infobar_width+infobar_spacing)*3,
			  y = miniprogressbar_top,
			  w = miniprogressbar_width,
			  h = miniprogressbar_height,
			  barheight = miniprogressbar_height,
			  min = 0,
			  max = 100,
			  barcolor = RedColor,
			  barcolor2 = TrasparentColor,
			  barimage = soldier_infobars_image,
			  percent  = false,
			},
			ProgressBar
			{
			  font = XenonautsDisabledFont,
			  name = "soldier4_apbar",
			 x = (infobar_init_x + miniprogressbar_left) + (infobar_width+infobar_spacing)*3,
			  y = miniprogressbar_top + miniprogressbar_vspacing*1,
			  w = miniprogressbar_width,
			  h = miniprogressbar_height,
			  barheight = miniprogressbar_height,
			  min = 0,
			  max = 100,
			  barcolor = OrangeColor,
			  barcolor2 = GreenColor,
			  barimage = soldier_infobars_image,
			  percent  = false,
			},
			ProgressBar
			{
			  font = XenonautsDisabledFont,
			  name = "soldier4_moralebar",
			  x = (infobar_init_x + miniprogressbar_left) + (infobar_width+infobar_spacing)*3,
			  y = miniprogressbar_top + miniprogressbar_vspacing*2,
			  w = miniprogressbar_width,
			  h = miniprogressbar_height,
			  barheight = miniprogressbar_height,
			  min = 0,
			  max = 100,
			  barcolor = BlueColor,
			  barcolor2 = TrasparentColor,
			  barimage = soldier_infobars_image,
			  percent  = false,
			},
			Window
			{
				name = "soldier4_miniPortraitPopup",
				x = infobar_init_x + (infobar_width+infobar_spacing)*3 + miniPortrait_hspacing + (160 * unit_info_scale_x) / 2,
				y = infobar_top - miniPortrait_height,
				w = miniPortrait_width + 160 * unit_info_scale_x,
				h = miniPortrait_height,
				
				NonUniformScaledImage
				{
				  name = "miniPortraitFrame",
				  x = 0,
				  y = 0,
				  w = miniPortrait_width,
				  h = miniPortrait_height,
				  image = "gui/GroundCombat/small/soldier_miniPortrait",
				  bordersize = 0,
				  
				  NonUniformScaledImage
				  {
					name = "miniPortrait",
					x = 1,
					y = 1,
					w = kMax - 1,
					h = kMax - 1,
					image = "soldierimages/face1",
					bordersize = 0,
				  },
				},
				
				ScalingText
				{
				  name = "soldierName",
				  x = miniPortrait_width + 1,
				  y = 0,
				  w = 160 * unit_info_scale_x - 2,
				  h = 13,
				  label = "#CPL. Jack Longname",
				  font = XenonautsDefaultFont,
				  fontScale = 1.0,
				},
				ScalingText
				{
				  name = "soldierRole",
				  x = miniPortrait_width + 1,
				  y = 13,
				  w = 160 * unit_info_scale_x - 2,
				  h = 13,
				  label = "#Rifleman",
				  font = XenonautsDefaultFont,
				  fontScale = 1.0,
				},
				NonUniformScaledImage
				{
				  name = "soldierRoleImage",
				  x = miniPortrait_width + 3,
				  y = 27,
				  w = 20,
				  h = 20,
				  --image = "uitextures/roles/unused",
				  aspectfix = 1.0;
				},
			},

			ScalingText --soldier5
		    {
			  font = XenonautsDefaultFont,
			  name = "soldier5_number",
			  x = infobar_init_x + (infobar_width+infobar_spacing)*4 + 8,
			  y = infobar_top + 3,
			  w = infobar_width,
			  h = infobar_height,
			  label = "#5",
			  fontScale = 1.0,
			},
			ProgressBar
			{
			  font = XenonautsDisabledFont,
			  name = "soldier5_hpbar",
			  x = (infobar_init_x + miniprogressbar_left) + (infobar_width+infobar_spacing)*4,
			  y = miniprogressbar_top,
			  w = miniprogressbar_width,
			  h = miniprogressbar_height,
			  barheight = miniprogressbar_height,
			  min = 0,
			  max = 100,
			  barcolor = RedColor,
			  barcolor2 = TrasparentColor,
			  barimage = soldier_infobars_image,
			  percent  = false,
			},
			ProgressBar
			{
			  font = XenonautsDisabledFont,
			  name = "soldier5_apbar",
			 x = (infobar_init_x + miniprogressbar_left) + (infobar_width+infobar_spacing)*4,
			  y = miniprogressbar_top + miniprogressbar_vspacing*1,
			  w = miniprogressbar_width,
			  h = miniprogressbar_height,
			  barheight = miniprogressbar_height,
			  min = 0,
			  max = 100,
			  barcolor = OrangeColor,
			  barcolor2 = GreenColor,
			  barimage = soldier_infobars_image,
			  percent  = false,
			},
			ProgressBar
			{
			  font = XenonautsDisabledFont,
			  name = "soldier5_moralebar",
			  x = (infobar_init_x + miniprogressbar_left) + (infobar_width+infobar_spacing)*4,
			  y = miniprogressbar_top + miniprogressbar_vspacing*2,
			  w = miniprogressbar_width,
			  h = miniprogressbar_height,
			  barheight = miniprogressbar_height,
			  min = 0,
			  max = 100,
			  barcolor = BlueColor,
			  barcolor2 = TrasparentColor,
			  barimage = soldier_infobars_image,
			  percent  = false,
			},
			Window
			{
				name = "soldier5_miniPortraitPopup",
				x = infobar_init_x + (infobar_width+infobar_spacing)*4 + miniPortrait_hspacing + (160 * unit_info_scale_x) / 2,
				y = infobar_top - miniPortrait_height,
				w = miniPortrait_width + 160 * unit_info_scale_x,
				h = miniPortrait_height,
				
				NonUniformScaledImage
				{
				  name = "miniPortraitFrame",
				  x = 0,
				  y = 0,
				  w = miniPortrait_width,
				  h = miniPortrait_height,
				  image = "gui/GroundCombat/small/soldier_miniPortrait",
				  bordersize = 0,
				  
				  NonUniformScaledImage
				  {
					name = "miniPortrait",
					x = 1,
					y = 1,
					w = kMax - 1,
					h = kMax - 1,
					image = "soldierimages/face1",
					bordersize = 0,
				  },
				},
				
				ScalingText
				{
				  name = "soldierName",
				  x = miniPortrait_width + 1,
				  y = 0,
				  w = 160 * unit_info_scale_x - 2,
				  h = 13,
				  label = "#CPL. Jack Longname",
				  font = XenonautsDefaultFont,
				  fontScale = 1.0,
				},
				ScalingText
				{
				  name = "soldierRole",
				  x = miniPortrait_width + 1,
				  y = 13,
				  w = 160 * unit_info_scale_x - 2,
				  h = 13,
				  label = "#Rifleman",
				  font = XenonautsDefaultFont,
				  fontScale = 1.0,
				},
				NonUniformScaledImage
				{
				  name = "soldierRoleImage",
				  x = miniPortrait_width + 3,
				  y = 27,
				  w = 20,
				  h = 20,
				  --image = "uitextures/roles/unused",
				  aspectfix = 1.0;
				},
			},

			ScalingText --soldier6
		    {
			  font = XenonautsDefaultFont,
			  name = "soldier6_number",
			  x = infobar_init_x + (infobar_width+infobar_spacing)*5 + 8,
			  y = infobar_top + 3,
			  w = infobar_width,
			  h = infobar_height,
			  label = "#6",
			  fontScale = 1.0,
			},			
			ProgressBar
			{
			  font = XenonautsDisabledFont,
			  name = "soldier6_hpbar",
			  x = (infobar_init_x + miniprogressbar_left) + (infobar_width+infobar_spacing)*5,
			  y = miniprogressbar_top,
			  w = miniprogressbar_width,
			  h = miniprogressbar_height,
			  barheight = miniprogressbar_height,
			  min = 0,
			  max = 100,
			  barcolor = RedColor,
			  barcolor2 = TrasparentColor,
			  barimage = soldier_infobars_image,
			  percent  = false,
			},
			ProgressBar
			{
			  font = XenonautsDisabledFont,
			  name = "soldier6_apbar",
			 x = (infobar_init_x + miniprogressbar_left) + (infobar_width+infobar_spacing)*5,
			  y = miniprogressbar_top + miniprogressbar_vspacing*1,
			  w = miniprogressbar_width,
			  h = miniprogressbar_height,
			  barheight = miniprogressbar_height,
			  min = 0,
			  max = 100,
			  barcolor = OrangeColor,
			  barcolor2 = GreenColor,
			  barimage = soldier_infobars_image,
			  percent  = false,
			},
			ProgressBar
			{
			  font = XenonautsDisabledFont,
			  name = "soldier6_moralebar",
			  x = (infobar_init_x + miniprogressbar_left) + (infobar_width+infobar_spacing)*5,
			  y = miniprogressbar_top + miniprogressbar_vspacing*2,
			  w = miniprogressbar_width,
			  h = miniprogressbar_height,
			  barheight = miniprogressbar_height,
			  min = 0,
			  max = 100,
			  barcolor = BlueColor,
			  barcolor2 = TrasparentColor,
			  barimage = soldier_infobars_image,
			  percent  = false,
			},
			Window
			{
				name = "soldier6_miniPortraitPopup",
				x = infobar_init_x + (infobar_width+infobar_spacing)*5 + miniPortrait_hspacing + (160 * unit_info_scale_x) / 2,
				y = infobar_top - miniPortrait_height,
				w = miniPortrait_width + 160 * unit_info_scale_x,
				h = miniPortrait_height,
				
				NonUniformScaledImage
				{
				  name = "miniPortraitFrame",
				  x = 0,
				  y = 0,
				  w = miniPortrait_width,
				  h = miniPortrait_height,
				  image = "gui/GroundCombat/small/soldier_miniPortrait",
				  bordersize = 0,
				  
				  NonUniformScaledImage
				  {
					name = "miniPortrait",
					x = 1,
					y = 1,
					w = kMax - 1,
					h = kMax - 1,
					image = "soldierimages/face1",
					bordersize = 0,
				  },
				},
				
				ScalingText
				{
				  name = "soldierName",
				  x = miniPortrait_width + 1,
				  y = 0,
				  w = 160 * unit_info_scale_x - 2,
				  h = 13,
				  label = "#CPL. Jack Longname",
				  font = XenonautsDefaultFont,
				  fontScale = 1.0,
				},
				ScalingText
				{
				  name = "soldierRole",
				  x = miniPortrait_width + 1,
				  y = 13,
				  w = 160 * unit_info_scale_x - 2,
				  h = 13,
				  label = "#Rifleman",
				  font = XenonautsDefaultFont,
				  fontScale = 1.0,
				},
				NonUniformScaledImage
				{
				  name = "soldierRoleImage",
				  x = miniPortrait_width + 3,
				  y = 27,
				  w = 20,
				  h = 20,
				  --image = "uitextures/roles/unused",
				  aspectfix = 1.0;
				},
			},

			ScalingText  --soldier7
		    {
			  font = XenonautsDefaultFont,
			  name = "soldier7_number",
			  x = infobar_init_x + (infobar_width+infobar_spacing)*6 + 8,
			  y = infobar_top + 3,
			  w = infobar_width,
			  h = infobar_height,
			  label = "#7",
			  fontScale = 1.0,
			},
			ProgressBar
			{
			  font = XenonautsDisabledFont,
			  name = "soldier7_hpbar",
			  x = (infobar_init_x + miniprogressbar_left) + (infobar_width+infobar_spacing)*6,
			  y = miniprogressbar_top,
			  w = miniprogressbar_width,
			  h = miniprogressbar_height,
			  barheight = miniprogressbar_height,
			  min = 0,
			  max = 100,
			  barcolor = RedColor,
			  barcolor2 = TrasparentColor,
			  barimage = soldier_infobars_image,
			  percent  = false,
			},
			ProgressBar
			{
			  font = XenonautsDisabledFont,
			  name = "soldier7_apbar",
			 x = (infobar_init_x + miniprogressbar_left) + (infobar_width+infobar_spacing)*6,
			  y = miniprogressbar_top + miniprogressbar_vspacing*1,
			  w = miniprogressbar_width,
			  h = miniprogressbar_height,
			  barheight = miniprogressbar_height,
			  min = 0,
			  max = 100,
			  barcolor = OrangeColor,
			  barcolor2 = GreenColor,
			  barimage = soldier_infobars_image,
			  percent  = false,
			},
			ProgressBar
			{
			  font = XenonautsDisabledFont,
			  name = "soldier7_moralebar",
			  x = (infobar_init_x + miniprogressbar_left) + (infobar_width+infobar_spacing)*6,
			  y = miniprogressbar_top + miniprogressbar_vspacing*2,
			  w = miniprogressbar_width,
			  h = miniprogressbar_height,
			  barheight = miniprogressbar_height,
			  min = 0,
			  max = 100,
			  barcolor = BlueColor,
			  barcolor2 = TrasparentColor,
			  barimage = soldier_infobars_image,
			  percent  = false,
			},
			Window
			{
				name = "soldier7_miniPortraitPopup",
				x = infobar_init_x + (infobar_width+infobar_spacing)*6 + miniPortrait_hspacing + (160 * unit_info_scale_x) / 2,
				y = infobar_top - miniPortrait_height,
				w = miniPortrait_width + 160 * unit_info_scale_x,
				h = miniPortrait_height,
				
				NonUniformScaledImage
				{
				  name = "miniPortraitFrame",
				  x = 0,
				  y = 0,
				  w = miniPortrait_width,
				  h = miniPortrait_height,
				  image = "gui/GroundCombat/small/soldier_miniPortrait",
				  bordersize = 0,
				  
				  NonUniformScaledImage
				  {
					name = "miniPortrait",
					x = 1,
					y = 1,
					w = kMax - 1,
					h = kMax - 1,
					image = "soldierimages/face1",
					bordersize = 0,
				  },
				},
				
				ScalingText
				{
				  name = "soldierName",
				  x = miniPortrait_width + 1,
				  y = 0,
				  w = 160 * unit_info_scale_x - 2,
				  h = 13,
				  label = "#CPL. Jack Longname",
				  font = XenonautsDefaultFont,
				  fontScale = 1.0,
				},
				ScalingText
				{
				  name = "soldierRole",
				  x = miniPortrait_width + 1,
				  y = 13,
				  w = 160 * unit_info_scale_x - 2,
				  h = 13,
				  label = "#Rifleman",
				  font = XenonautsDefaultFont,
				  fontScale = 1.0,
				},
				NonUniformScaledImage
				{
				  name = "soldierRoleImage",
				  x = miniPortrait_width + 3,
				  y = 27,
				  w = 20,
				  h = 20,
				  --image = "uitextures/roles/unused",
				  aspectfix = 1.0;
				},
			},

			ScalingText --soldier8
		    {
			  font = XenonautsDefaultFont,
			  name = "soldier8_number",
			  x = infobar_init_x + (infobar_width+infobar_spacing)*7 + 8,
			  y = infobar_top + 3,
			  w = infobar_width,
			  h = infobar_height,
			  label = "#8",
			  fontScale = 1.0,
			},
			ProgressBar
			{
			  font = XenonautsDisabledFont,
			  name = "soldier8_hpbar",
			  x = (infobar_init_x + miniprogressbar_left) + (infobar_width+infobar_spacing)*7,
			  y = miniprogressbar_top,
			  w = miniprogressbar_width,
			  h = miniprogressbar_height,
			  barheight = miniprogressbar_height,
			  min = 0,
			  max = 100,
			  barcolor = RedColor,
			  barcolor2 = TrasparentColor,
			  barimage = soldier_infobars_image,
			  percent  = false,
			},
			ProgressBar
			{
			  font = XenonautsDisabledFont,
			  name = "soldier8_apbar",
			  x = (infobar_init_x + miniprogressbar_left) + (infobar_width+infobar_spacing)*7,
			  y = miniprogressbar_top + miniprogressbar_vspacing*1,
			  w = miniprogressbar_width,
			  h = miniprogressbar_height,
			  barheight = miniprogressbar_height,
			  min = 0,
			  max = 100,
			  barcolor = OrangeColor,
			  barcolor2 = GreenColor,
			  barimage = soldier_infobars_image,
			  percent  = false,
			},
			ProgressBar
			{
			  font = XenonautsDisabledFont,
			  name = "soldier8_moralebar",
			  x = (infobar_init_x + miniprogressbar_left) + (infobar_width+infobar_spacing)*7,
			  y = miniprogressbar_top + miniprogressbar_vspacing*2,
			  w = miniprogressbar_width,
			  h = miniprogressbar_height,
			  barheight = miniprogressbar_height,
			  min = 0,
			  max = 100,
			  barcolor = BlueColor,
			  barcolor2 = TrasparentColor,
			  barimage = soldier_infobars_image,
			  percent  = false,
			},
			Window
			{
				name = "soldier8_miniPortraitPopup",
				x = infobar_init_x + (infobar_width+infobar_spacing)*7 + miniPortrait_hspacing + (160 * unit_info_scale_x) / 2,
				y = infobar_top - miniPortrait_height,
				w = miniPortrait_width + 160 * unit_info_scale_x,
				h = miniPortrait_height,
				
				NonUniformScaledImage
				{
				  name = "miniPortraitFrame",
				  x = 0,
				  y = 0,
				  w = miniPortrait_width,
				  h = miniPortrait_height,
				  image = "gui/GroundCombat/small/soldier_miniPortrait",
				  bordersize = 0,
				  
				  NonUniformScaledImage
				  {
					name = "miniPortrait",
					x = 1,
					y = 1,
					w = kMax - 1,
					h = kMax - 1,
					image = "soldierimages/face1",
					bordersize = 0,
				  },
				},
				
				ScalingText
				{
				  name = "soldierName",
				  x = miniPortrait_width + 1,
				  y = 0,
				  w = 160 * unit_info_scale_x - 2,
				  h = 13,
				  label = "#CPL. Jack Longname",
				  font = XenonautsDefaultFont,
				  fontScale = 1.0,
				},
				ScalingText
				{
				  name = "soldierRole",
				  x = miniPortrait_width + 1,
				  y = 13,
				  w = 160 * unit_info_scale_x - 2,
				  h = 13,
				  label = "#Rifleman",
				  font = XenonautsDefaultFont,
				  fontScale = 1.0,
				},
				NonUniformScaledImage
				{
				  name = "soldierRoleImage",
				  x = miniPortrait_width + 3,
				  y = 27,
				  w = 20,
				  h = 20,
				  --image = "uitextures/roles/unused",
				  aspectfix = 1.0;
				},
			},

			ScalingText --soldier9
		    {
			  font = XenonautsDefaultFont,
			  name = "soldier9_number",
			  x = infobar_init_x + (infobar_width+infobar_spacing)*8 + 8,
			  y = infobar_top + 3,
			  w = infobar_width,
			  h = infobar_height,
			  label = "#9",
			  fontScale = 1.0,
			},
			ProgressBar
			{
			  font = XenonautsDisabledFont,
			  name = "soldier9_hpbar",
			  x = (infobar_init_x + miniprogressbar_left) + (infobar_width+infobar_spacing)*8,
			  y = miniprogressbar_top,
			  w = miniprogressbar_width,
			  h = miniprogressbar_height,
			  barheight = miniprogressbar_height,
			  min = 0,
			  max = 100,
			  barcolor = RedColor,
			  barcolor2 = TrasparentColor,
			  barimage = soldier_infobars_image,
			  percent  = false,
			},
			ProgressBar
			{
			  font = XenonautsDisabledFont,
			  name = "soldier9_apbar",
			  x = (infobar_init_x + miniprogressbar_left) + (infobar_width+infobar_spacing)*8,
			  y = miniprogressbar_top + miniprogressbar_vspacing*1,
			  w = miniprogressbar_width,
			  h = miniprogressbar_height,
			  barheight = miniprogressbar_height,
			  min = 0,
			  max = 100,
			  barcolor = OrangeColor,
			  barcolor2 = GreenColor,
			  barimage = soldier_infobars_image,
			  percent  = false,
			},
			ProgressBar
			{
			  font = XenonautsDisabledFont,
			  name = "soldier9_moralebar",
			  x = (infobar_init_x + miniprogressbar_left) + (infobar_width+infobar_spacing)*8,
			  y = miniprogressbar_top + miniprogressbar_vspacing*2,
			  w = miniprogressbar_width,
			  h = miniprogressbar_height,
			  barheight = miniprogressbar_height,
			  min = 0,
			  max = 100,
			  barcolor = BlueColor,
			  barcolor2 = TrasparentColor,
			  barimage = soldier_infobars_image,
			  percent  = false,
			},
			Window
			{
				name = "soldier9_miniPortraitPopup",
				x = infobar_init_x + (infobar_width+infobar_spacing)*8 + miniPortrait_hspacing + (160 * unit_info_scale_x) / 2,
				y = infobar_top - miniPortrait_height,
				w = miniPortrait_width + 160 * unit_info_scale_x,
				h = miniPortrait_height,
				
				NonUniformScaledImage
				{
				  name = "miniPortraitFrame",
				  x = 0,
				  y = 0,
				  w = miniPortrait_width,
				  h = miniPortrait_height,
				  image = "gui/GroundCombat/small/soldier_miniPortrait",
				  bordersize = 0,
				  
				  NonUniformScaledImage
				  {
					name = "miniPortrait",
					x = 1,
					y = 1,
					w = kMax - 1,
					h = kMax - 1,
					image = "soldierimages/face1",
					bordersize = 0,
				  },
				},
				
				ScalingText
				{
				  name = "soldierName",
				  x = miniPortrait_width + 1,
				  y = 0,
				  w = 160 * unit_info_scale_x - 2,
				  h = 13,
				  label = "#CPL. Jack Longname",
				  font = XenonautsDefaultFont,
				  fontScale = 1.0,
				},
				ScalingText
				{
				  name = "soldierRole",
				  x = miniPortrait_width + 1,
				  y = 13,
				  w = 160 * unit_info_scale_x - 2,
				  h = 13,
				  label = "#Rifleman",
				  font = XenonautsDefaultFont,
				  fontScale = 1.0,
				},
				NonUniformScaledImage
				{
				  name = "soldierRoleImage",
				  x = miniPortrait_width + 3,
				  y = 27,
				  w = 20,
				  h = 20,
				  --image = "uitextures/roles/unused",
				  aspectfix = 1.0;
				},
			},

			ScalingText --soldier10
		    {
			  font = XenonautsDefaultFont,
			  name = "soldier10_number",
			  x = infobar_init_x + (infobar_width+infobar_spacing)*9 + 8,
			  y = infobar_top + 3,
			  w = infobar_width,
			  h = infobar_height,
			  label = "#10",
			  fontScale = 1.0,
			},
			ProgressBar
			{
			  font = XenonautsDisabledFont,
			  name = "soldier10_hpbar",
			  x = (infobar_init_x + miniprogressbar_left) + (infobar_width+infobar_spacing)*9,
			  y = miniprogressbar_top,
			  w = miniprogressbar_width,
			  h = miniprogressbar_height,
			  barheight = miniprogressbar_height,
			  min = 0,
			  max = 100,
			  barcolor = RedColor,
			  barcolor2 = TrasparentColor,
			  barimage = soldier_infobars_image,
			  percent  = false,
			},
			ProgressBar
			{
			  font = XenonautsDisabledFont,
			  name = "soldier10_apbar",
			 x = (infobar_init_x + miniprogressbar_left) + (infobar_width+infobar_spacing)*9,
			  y = miniprogressbar_top + miniprogressbar_vspacing*1,
			  w = miniprogressbar_width,
			  h = miniprogressbar_height,
			  barheight = miniprogressbar_height,
			  min = 0,
			  max = 100,
			  barcolor = OrangeColor,
			  barcolor2 = GreenColor,
			  barimage = soldier_infobars_image,
			  percent  = false,
			},
			ProgressBar
			{
			  font = XenonautsDisabledFont,
			  name = "soldier10_moralebar",
			  x = (infobar_init_x + miniprogressbar_left) + (infobar_width+infobar_spacing)*9,
			  y = miniprogressbar_top + miniprogressbar_vspacing*2,
			  w = miniprogressbar_width,
			  h = miniprogressbar_height,
			  barheight = miniprogressbar_height,
			  min = 0,
			  max = 100,
			  barcolor = BlueColor,
			  barcolor2 = TrasparentColor,
			  barimage = soldier_infobars_image,
			  percent  = false,
			},
			Window
			{
				name = "soldier10_miniPortraitPopup",
				x = infobar_init_x + (infobar_width+infobar_spacing)*9 + miniPortrait_hspacing + (160 * unit_info_scale_x) / 2,
				y = infobar_top - miniPortrait_height,
				w = miniPortrait_width + 160 * unit_info_scale_x,
				h = miniPortrait_height,
				
				NonUniformScaledImage
				{
				  name = "miniPortraitFrame",
				  x = 0,
				  y = 0,
				  w = miniPortrait_width,
				  h = miniPortrait_height,
				  image = "gui/GroundCombat/small/soldier_miniPortrait",
				  bordersize = 0,
				  
				  NonUniformScaledImage
				  {
					name = "miniPortrait",
					x = 1,
					y = 1,
					w = kMax - 1,
					h = kMax - 1,
					image = "soldierimages/face1",
					bordersize = 0,
				  },
				},
				
				ScalingText
				{
				  name = "soldierName",
				  x = miniPortrait_width + 1,
				  y = 0,
				  w = 160 * unit_info_scale_x - 2,
				  h = 13,
				  label = "#CPL. Jack Longname",
				  font = XenonautsDefaultFont,
				  fontScale = 1.0,
				},
				ScalingText
				{
				  name = "soldierRole",
				  x = miniPortrait_width + 1,
				  y = 13,
				  w = 160 * unit_info_scale_x - 2,
				  h = 13,
				  label = "#Rifleman",
				  font = XenonautsDefaultFont,
				  fontScale = 1.0,
				},
				NonUniformScaledImage
				{
				  name = "soldierRoleImage",
				  x = miniPortrait_width + 3,
				  y = 27,
				  w = 20,
				  h = 20,
				  --image = "uitextures/roles/unused",
				  aspectfix = 1.0;
				},
			},

			ScalingText --soldier11
		    {
			  font = XenonautsDefaultFont,
			  name = "soldier11_number",
			  x = infobar_init_x + (infobar_width+infobar_spacing)*10 + 8,
			  y = infobar_top + 3,
			  w = infobar_width,
			  h = infobar_height,
			  label = "#11",
			  fontScale = 1.0,
			},
			ProgressBar
			{
			  font = XenonautsDisabledFont,
			  name = "soldier11_hpbar",
			  x = (infobar_init_x + miniprogressbar_left) + (infobar_width+infobar_spacing)*10,
			  y = miniprogressbar_top,
			  w = miniprogressbar_width,
			  h = miniprogressbar_height,
			  barheight = miniprogressbar_height,
			  min = 0,
			  max = 100,
			  barcolor = RedColor,
			  barcolor2 = TrasparentColor,
			  barimage = soldier_infobars_image,
			  percent  = false,
			},
			ProgressBar
			{
			  font = XenonautsDisabledFont,
			  name = "soldier11_apbar",
			  x = (infobar_init_x + miniprogressbar_left) + (infobar_width+infobar_spacing)*10,
			  y = miniprogressbar_top + miniprogressbar_vspacing*1,
			  w = miniprogressbar_width,
			  h = miniprogressbar_height,
			  barheight = miniprogressbar_height,
			  min = 0,
			  max = 100,
			  barcolor = OrangeColor,
			  barcolor2 = GreenColor,
			  barimage = soldier_infobars_image,
			  percent  = false,
			},
			ProgressBar
			{
			  font = XenonautsDisabledFont,
			  name = "soldier11_moralebar",
			  x = (infobar_init_x + miniprogressbar_left) + (infobar_width+infobar_spacing)*10,
			  y = miniprogressbar_top + miniprogressbar_vspacing*2,
			  w = miniprogressbar_width,
			  h = miniprogressbar_height,
			  barheight = miniprogressbar_height,
			  min = 0,
			  max = 100,
			  barcolor = BlueColor,
			  barcolor2 = TrasparentColor,
			  barimage = soldier_infobars_image,
			  percent  = false,
			},
			Window
			{
				name = "soldier11_miniPortraitPopup",
				x = infobar_init_x + (infobar_width+infobar_spacing)*10 + miniPortrait_hspacing + (160 * unit_info_scale_x) / 2,
				y = infobar_top - miniPortrait_height,
				w = miniPortrait_width + 160 * unit_info_scale_x,
				h = miniPortrait_height,
				
				NonUniformScaledImage
				{
				  name = "miniPortraitFrame",
				  x = 0,
				  y = 0,
				  w = miniPortrait_width,
				  h = miniPortrait_height,
				  image = "gui/GroundCombat/small/soldier_miniPortrait",
				  bordersize = 0,
				  
				  NonUniformScaledImage
				  {
					name = "miniPortrait",
					x = 1,
					y = 1,
					w = kMax - 1,
					h = kMax - 1,
					image = "soldierimages/face1",
					bordersize = 0,
				  },
				},
				
				ScalingText
				{
				  name = "soldierName",
				  x = miniPortrait_width + 1,
				  y = 0,
				  w = 160 * unit_info_scale_x - 2,
				  h = 13,
				  label = "#CPL. Jack Longname",
				  font = XenonautsDefaultFont,
				  fontScale = 1.0,
				},
				ScalingText
				{
				  name = "soldierRole",
				  x = miniPortrait_width + 1,
				  y = 13,
				  w = 160 * unit_info_scale_x - 2,
				  h = 13,
				  label = "#Rifleman",
				  font = XenonautsDefaultFont,
				  fontScale = 1.0,
				},
				NonUniformScaledImage
				{
				  name = "soldierRoleImage",
				  x = miniPortrait_width + 3,
				  y = 27,
				  w = 20,
				  h = 20,
				  --image = "uitextures/roles/unused",
				  aspectfix = 1.0;
				},
			},

			ScalingText --soldier12
		    {
			  font = XenonautsDefaultFont,
			  name = "soldier12_number",
			  x = infobar_init_x + (infobar_width+infobar_spacing)*11 + 8,
			  y = infobar_top + 3,
			  w = infobar_width,
			  h = infobar_height,
			  label = "#12",
			  fontScale = 1.0,
			},
			ProgressBar
			{
			  font = XenonautsDisabledFont,
			  name = "soldier12_hpbar",
			  x = (infobar_init_x + miniprogressbar_left) + (infobar_width+infobar_spacing)*11,
			  y = miniprogressbar_top,
			  w = miniprogressbar_width,
			  h = miniprogressbar_height,
			  barheight = miniprogressbar_height,
			  min = 0,
			  max = 100,
			  barcolor = RedColor,
			  barcolor2 = TrasparentColor,
			  barimage = soldier_infobars_image,
			  percent  = false,
			},
			ProgressBar
			{
			  font = XenonautsDisabledFont,
			  name = "soldier12_apbar",
			  x = (infobar_init_x + miniprogressbar_left) + (infobar_width+infobar_spacing)*11,
			  y = miniprogressbar_top + miniprogressbar_vspacing*1,
			  w = miniprogressbar_width,
			  h = miniprogressbar_height,
			  barheight = miniprogressbar_height,
			  min = 0,
			  max = 100,
			  barcolor = OrangeColor,
			  barcolor2 = GreenColor,
			  barimage = soldier_infobars_image,
			  percent  = false,
			},
			ProgressBar
			{
			  font = XenonautsDisabledFont,
			  name = "soldier12_moralebar",
			  x = (infobar_init_x + miniprogressbar_left) + (infobar_width+infobar_spacing)*11,
			  y = miniprogressbar_top + miniprogressbar_vspacing*2,
			  w = miniprogressbar_width,
			  h = miniprogressbar_height,
			  barheight = miniprogressbar_height,
			  min = 0,
			  max = 100,
			  barcolor = BlueColor,
			  barcolor2 = TrasparentColor,
			  barimage = soldier_infobars_image,
			  percent  = false,
			},
			Window
			{
				name = "soldier12_miniPortraitPopup",
				x = infobar_init_x + (infobar_width+infobar_spacing)*11 + miniPortrait_hspacing + (160 * unit_info_scale_x) / 2,
				y = infobar_top - miniPortrait_height,
				w = miniPortrait_width + 160 * unit_info_scale_x,
				h = miniPortrait_height,
				
				NonUniformScaledImage
				{
				  name = "miniPortraitFrame",
				  x = 0,
				  y = 0,
				  w = miniPortrait_width,
				  h = miniPortrait_height,
				  image = "gui/GroundCombat/small/soldier_miniPortrait",
				  bordersize = 0,
				  
				  NonUniformScaledImage
				  {
					name = "miniPortrait",
					x = 1,
					y = 1,
					w = kMax - 1,
					h = kMax - 1,
					image = "soldierimages/face1",
					bordersize = 0,
				  },
				},
				
				ScalingText
				{
				  name = "soldierName",
				  x = miniPortrait_width + 1,
				  y = 0,
				  w = 160 * unit_info_scale_x - 2,
				  h = 13,
				  label = "#CPL. Jack Longname",
				  font = XenonautsDefaultFont,
				  fontScale = 1.0,
				},
				ScalingText
				{
				  name = "soldierRole",
				  x = miniPortrait_width + 1,
				  y = 13,
				  w = 160 * unit_info_scale_x - 2,
				  h = 13,
				  label = "#Rifleman",
				  font = XenonautsDefaultFont,
				  fontScale = 1.0,
				},
				NonUniformScaledImage
				{
				  name = "soldierRoleImage",
				  x = miniPortrait_width + 3,
				  y = 27,
				  w = 20,
				  h = 20,
				  --image = "uitextures/roles/unused",
				  aspectfix = 1.0;
				},
			},

			ScalingText --soldier13
		    {
			  font = XenonautsDefaultFont,
			  name = "soldier13_number",
			  x = infobar_init_x + (infobar_width+infobar_spacing)*12 + 8,
			  y = infobar_top + 3,
			  w = infobar_width,
			  h = infobar_height,
			  label = "#13",
			  fontScale = 1.0,
			},
			ProgressBar
			{
			  font = XenonautsDisabledFont,
			  name = "soldier13_hpbar",
			  x = (infobar_init_x + miniprogressbar_left) + (infobar_width+infobar_spacing)*12,
			  y = miniprogressbar_top,
			  w = miniprogressbar_width,
			  h = miniprogressbar_height,
			  barheight = miniprogressbar_height,
			  min = 0,
			  max = 100,
			  barcolor = RedColor,
			  barcolor2 = TrasparentColor,
			  barimage = soldier_infobars_image,
			  percent  = false,
			},
			ProgressBar
			{
			  font = XenonautsDisabledFont,
			  name = "soldier13_apbar",
			  x = (infobar_init_x + miniprogressbar_left) + (infobar_width+infobar_spacing)*12,
			  y = miniprogressbar_top + miniprogressbar_vspacing*1,
			  w = miniprogressbar_width,
			  h = miniprogressbar_height,
			  barheight = miniprogressbar_height,
			  min = 0,
			  max = 100,
			  barcolor = OrangeColor,
			  barcolor2 = GreenColor,
			  barimage = soldier_infobars_image,
			  percent  = false,
			},
			ProgressBar
			{
			  font = XenonautsDisabledFont,
			  name = "soldier13_moralebar",
			  x = (infobar_init_x + miniprogressbar_left) + (infobar_width+infobar_spacing)*12,
			  y = miniprogressbar_top + miniprogressbar_vspacing*2,
			  w = miniprogressbar_width,
			  h = miniprogressbar_height,
			  barheight = miniprogressbar_height,
			  min = 0,
			  max = 100,
			  barcolor = BlueColor,
			  barcolor2 = TrasparentColor,
			  barimage = soldier_infobars_image,
			  percent  = false,
			},
			Window
			{
				name = "soldier13_miniPortraitPopup",
				x = infobar_init_x + (infobar_width+infobar_spacing)*12 + miniPortrait_hspacing + (160 * unit_info_scale_x) / 2,
				y = infobar_top - miniPortrait_height,
				w = miniPortrait_width + 160 * unit_info_scale_x,
				h = miniPortrait_height,
				
				NonUniformScaledImage
				{
				  name = "miniPortraitFrame",
				  x = 0,
				  y = 0,
				  w = miniPortrait_width,
				  h = miniPortrait_height,
				  image = "gui/GroundCombat/small/soldier_miniPortrait",
				  bordersize = 0,
				  
				  NonUniformScaledImage
				  {
					name = "miniPortrait",
					x = 1,
					y = 1,
					w = kMax - 1,
					h = kMax - 1,
					image = "soldierimages/face1",
					bordersize = 0,
				  },
				},
				
				ScalingText
				{
				  name = "soldierName",
				  x = miniPortrait_width + 1,
				  y = 0,
				  w = 160 * unit_info_scale_x - 2,
				  h = 13,
				  label = "#CPL. Jack Longname",
				  font = XenonautsDefaultFont,
				  fontScale = 1.0,
				},
				ScalingText
				{
				  name = "soldierRole",
				  x = miniPortrait_width + 1,
				  y = 13,
				  w = 160 * unit_info_scale_x - 2,
				  h = 13,
				  label = "#Rifleman",
				  font = XenonautsDefaultFont,
				  fontScale = 1.0,
				},
				NonUniformScaledImage
				{
				  name = "soldierRoleImage",
				  x = miniPortrait_width + 3,
				  y = 27,
				  w = 20,
				  h = 20,
				  --image = "uitextures/roles/unused",
				  aspectfix = 1.0;
				},
			},

			ScalingText --soldier14
		    {
			  font = XenonautsDefaultFont,
			  name = "soldier14_number",
			  x = infobar_init_x + (infobar_width+infobar_spacing)*13 + 8,
			  y = infobar_top + 3,
			  w = infobar_width,
			  h = infobar_height,
			  label = "#14",
			  fontScale = 1.0,
			},
			ProgressBar
			{
			  font = XenonautsDisabledFont,
			  name = "soldier14_hpbar",
			  x = (infobar_init_x + miniprogressbar_left) + (infobar_width+infobar_spacing)*13,
			  y = miniprogressbar_top,
			  w = miniprogressbar_width,
			  h = miniprogressbar_height,
			  barheight = miniprogressbar_height,
			  min = 0,
			  max = 100,
			  barcolor = RedColor,
			  barcolor2 = TrasparentColor,
			  barimage = soldier_infobars_image,
			  percent  = false,
			},
			ProgressBar
			{
			  font = XenonautsDisabledFont,
			  name = "soldier14_apbar",
			  x = (infobar_init_x + miniprogressbar_left) + (infobar_width+infobar_spacing)*13,
			  y = miniprogressbar_top + miniprogressbar_vspacing*1,
			  w = miniprogressbar_width,
			  h = miniprogressbar_height,
			  barheight = miniprogressbar_height,
			  min = 0,
			  max = 100,
			  barcolor = OrangeColor,
			  barcolor2 = GreenColor,
			  barimage = soldier_infobars_image,
			  percent  = false,
			},
			ProgressBar
			{
			  font = XenonautsDisabledFont,
			  name = "soldier14_moralebar",
			  x = (infobar_init_x + miniprogressbar_left) + (infobar_width+infobar_spacing)*13,
			  y = miniprogressbar_top + miniprogressbar_vspacing*2,
			  w = miniprogressbar_width,
			  h = miniprogressbar_height,
			  barheight = miniprogressbar_height,
			  min = 0,
			  max = 100,
			  barcolor = BlueColor,
			  barcolor2 = TrasparentColor,
			  barimage = soldier_infobars_image,
			  percent  = false,
			},
			Window
			{
				name = "soldier14_miniPortraitPopup",
				x = infobar_init_x + (infobar_width+infobar_spacing)*13 + miniPortrait_hspacing + (160 * unit_info_scale_x) / 2,
				y = infobar_top - miniPortrait_height,
				w = miniPortrait_width + 160 * unit_info_scale_x,
				h = miniPortrait_height,
				
				NonUniformScaledImage
				{
				  name = "miniPortraitFrame",
				  x = 0,
				  y = 0,
				  w = miniPortrait_width,
				  h = miniPortrait_height,
				  image = "gui/GroundCombat/small/soldier_miniPortrait",
				  bordersize = 0,
				  
				  NonUniformScaledImage
				  {
					name = "miniPortrait",
					x = 1,
					y = 1,
					w = kMax - 1,
					h = kMax - 1,
					image = "soldierimages/face1",
					bordersize = 0,
				  },
				},
				
				ScalingText
				{
				  name = "soldierName",
				  x = miniPortrait_width + 1,
				  y = 0,
				  w = 160 * unit_info_scale_x - 2,
				  h = 13,
				  label = "#CPL. Jack Longname",
				  font = XenonautsDefaultFont,
				  fontScale = 1.0,
				},
				ScalingText
				{
				  name = "soldierRole",
				  x = miniPortrait_width + 1,
				  y = 13,
				  w = 160 * unit_info_scale_x - 2,
				  h = 13,
				  label = "#Rifleman",
				  font = XenonautsDefaultFont,
				  fontScale = 1.0,
				},
				NonUniformScaledImage
				{
				  name = "soldierRoleImage",
				  x = miniPortrait_width + 3,
				  y = 27,
				  w = 20,
				  h = 20,
				  --image = "uitextures/roles/unused",
				  aspectfix = 1.0;
				},
			},

			ScalingText --soldier15
		    {
			  font = XenonautsDefaultFont,
			  name = "soldier15_number",
			  x = infobar_init_x + (infobar_width+infobar_spacing)*14 + 8,
			  y = infobar_top + 3,
			  w = infobar_width,
			  h = infobar_height,
			  label = "#15",
			  fontScale = 1.0,
			},
			ProgressBar
			{
			  font = XenonautsDisabledFont,
			  name = "soldier15_hpbar",
			  x = (infobar_init_x + miniprogressbar_left) + (infobar_width+infobar_spacing)*14,
			  y = miniprogressbar_top,
			  w = miniprogressbar_width,
			  h = miniprogressbar_height,
			  barheight = miniprogressbar_height,
			  min = 0,
			  max = 100,
			  barcolor = RedColor,
			  barcolor2 = TrasparentColor,
			  barimage = soldier_infobars_image,
			  percent  = false,
			},
			ProgressBar
			{
			  font = XenonautsDisabledFont,
			  name = "soldier15_apbar",
			  x = (infobar_init_x + miniprogressbar_left) + (infobar_width+infobar_spacing)*14,
			  y = miniprogressbar_top + miniprogressbar_vspacing*1,
			  w = miniprogressbar_width,
			  h = miniprogressbar_height,
			  barheight = miniprogressbar_height,
			  min = 0,
			  max = 100,
			  barcolor = OrangeColor,
			  barcolor2 = GreenColor,
			  barimage = soldier_infobars_image,
			  percent  = false,
			},
			ProgressBar
			{
			  font = XenonautsDisabledFont,
			  name = "soldier15_moralebar",
			  x = (infobar_init_x + miniprogressbar_left) + (infobar_width+infobar_spacing)*14,
			  y = miniprogressbar_top + miniprogressbar_vspacing*2,
			  w = miniprogressbar_width,
			  h = miniprogressbar_height,
			  barheight = miniprogressbar_height,
			  min = 0,
			  max = 100,
			  barcolor = BlueColor,
			  barcolor2 = TrasparentColor,
			  barimage = soldier_infobars_image,
			  percent  = false,
			},
			Window
			{
				name = "soldier15_miniPortraitPopup",
				x = infobar_init_x + (infobar_width+infobar_spacing)*14 + miniPortrait_hspacing + (160 * unit_info_scale_x) / 2,
				y = infobar_top - miniPortrait_height,
				w = miniPortrait_width + 160 * unit_info_scale_x,
				h = miniPortrait_height,
				
				NonUniformScaledImage
				{
				  name = "miniPortraitFrame",
				  x = 0,
				  y = 0,
				  w = miniPortrait_width,
				  h = miniPortrait_height,
				  image = "gui/GroundCombat/small/soldier_miniPortrait",
				  bordersize = 0,
				  
				  NonUniformScaledImage
				  {
					name = "miniPortrait",
					x = 1,
					y = 1,
					w = kMax - 1,
					h = kMax - 1,
					image = "soldierimages/face1",
					bordersize = 0,
				  },
				},
				
				ScalingText
				{
				  name = "soldierName",
				  x = miniPortrait_width + 1,
				  y = 0,
				  w = 160 * unit_info_scale_x - 2,
				  h = 13,
				  label = "#CPL. Jack Longname",
				  font = XenonautsDefaultFont,
				  fontScale = 1.0,
				},
				ScalingText
				{
				  name = "soldierRole",
				  x = miniPortrait_width + 1,
				  y = 13,
				  w = 160 * unit_info_scale_x - 2,
				  h = 13,
				  label = "#Rifleman",
				  font = XenonautsDefaultFont,
				  fontScale = 1.0,
				},
				NonUniformScaledImage
				{
				  name = "soldierRoleImage",
				  x = miniPortrait_width + 3,
				  y = 27,
				  w = 20,
				  h = 20,
				  --image = "uitextures/roles/unused",
				  aspectfix = 1.0;
				},
			},

			ScalingText --soldier16
		    {
			  font = XenonautsDefaultFont,
			  name = "soldier16_number",
			  x = infobar_init_x + (infobar_width+infobar_spacing)*15 + 8,
			  y = infobar_top + 3,
			  w = infobar_width,
			  h = infobar_height,
			  label = "#16",
			  fontScale = 1.0,
			},
			ProgressBar
			{
			  font = XenonautsDisabledFont,
			  name = "soldier16_hpbar",
			  x = (infobar_init_x + miniprogressbar_left) + (infobar_width+infobar_spacing)*15,
			  y = miniprogressbar_top,
			  w = miniprogressbar_width,
			  h = miniprogressbar_height,
			  barheight = miniprogressbar_height,
			  min = 0,
			  max = 100,
			  barcolor = RedColor,
			  barcolor2 = TrasparentColor,
			  barimage = soldier_infobars_image,
			  percent  = false,
			},
			ProgressBar
			{
			  font = XenonautsDisabledFont,
			  name = "soldier16_apbar",
			  x = (infobar_init_x + miniprogressbar_left) + (infobar_width+infobar_spacing)*15,
			  y = miniprogressbar_top + miniprogressbar_vspacing*1,
			  w = miniprogressbar_width,
			  h = miniprogressbar_height,
			  barheight = miniprogressbar_height,
			  min = 0,
			  max = 100,
			  barcolor = OrangeColor,
			  barcolor2 = GreenColor,
			  barimage = soldier_infobars_image,
			  percent  = false,
			},
			ProgressBar
			{
			  font = XenonautsDisabledFont,
			  name = "soldier16_moralebar",
			  x = (infobar_init_x + miniprogressbar_left) + (infobar_width+infobar_spacing)*15,
			  y = miniprogressbar_top + miniprogressbar_vspacing*2,
			  w = miniprogressbar_width,
			  h = miniprogressbar_height,
			  barheight = miniprogressbar_height,
			  min = 0,
			  max = 100,
			  barcolor = BlueColor,
			  barcolor2 = TrasparentColor,
			  barimage = soldier_infobars_image,
			  percent  = false,
			},
			Window
			{
				name = "soldier16_miniPortraitPopup",
				x = infobar_init_x + (infobar_width+infobar_spacing)*15 + miniPortrait_hspacing + (160 * unit_info_scale_x) / 2,
				y = infobar_top - miniPortrait_height,
				w = miniPortrait_width + 160 * unit_info_scale_x,
				h = miniPortrait_height,
				
				NonUniformScaledImage
				{
				  name = "miniPortraitFrame",
				  x = 0,
				  y = 0,
				  w = miniPortrait_width,
				  h = miniPortrait_height,
				  image = "gui/GroundCombat/small/soldier_miniPortrait",
				  bordersize = 0,
				  
				  NonUniformScaledImage
				  {
					name = "miniPortrait",
					x = 1,
					y = 1,
					w = kMax - 1,
					h = kMax - 1,
					image = "soldierimages/face1",
					bordersize = 0,
				  },
				},
				
				ScalingText
				{
				  name = "soldierName",
				  x = miniPortrait_width + 1,
				  y = 0,
				  w = 160 * unit_info_scale_x - 2,
				  h = 13,
				  label = "#CPL. Jack Longname",
				  font = XenonautsDefaultFont,
				  fontScale = 1.0,
				},
				ScalingText
				{
				  name = "soldierRole",
				  x = miniPortrait_width + 1,
				  y = 13,
				  w = 160 * unit_info_scale_x - 2,
				  h = 13,
				  label = "#Rifleman",
				  font = XenonautsDefaultFont,
				  fontScale = 1.0,
				},
				NonUniformScaledImage
				{
				  name = "soldierRoleImage",
				  x = miniPortrait_width + 3,
				  y = 27,
				  w = 20,
				  h = 20,
				  --image = "uitextures/roles/unused",
				  aspectfix = 1.0;
				},
			},

			----------------------------
			-- Primary weapon buttons --
			----------------------------
			WeaponButton
			{
				x		 = primary_wep_btn_left,
				y		 = primary_wep_btn_top,
				name	 = "primary_wep",
				label	 = "primary_wep",
				graphics = primary_wep_graphics,
				type	 = kToggle,
				
				command =
					function()
						GUIEventHandler("primary_wep", 1);
					end,
			},
			TooltipRect
			{
				x = primary_wep_btn_left,
				y = primary_wep_btn_top,
				w = primary_wep_btn_width,
				h = primary_wep_btn_height,
				
				text="GcGUI.Tooltips.EquipmentTile",
				uppercase = false,
			},
			
			BeginGroup(),
			Button
			{
				x		 = fire_mode_left,
				y		 = fire_mode_top,
				name	 = "primary_wep_single_shot",
				label	 = "primary_wep_single_shot",
				graphics = fire_mode_graphics,
				type	 = kRadio,
				
				command =
					function()
						GUIEventHandler("primary_wep_single_shot", 1);
					end,
			},
			Button
			{
				x		 = fire_mode_left + fire_mode_width + fire_mode_spacing,
				y		 = fire_mode_top,
				name	 = "primary_wep_burst_fire",
				label	 = "primary_wep_burst_fire",
				graphics = fire_mode_graphics,
				type	 = kRadio,
				
				command =
					function()
						GUIEventHandler("primary_wep_burst_fire", 1);
					end,
			},
			BeginGroup(),
			--[[Button
			{
				x		 = reload_weapon_left,
				y		 = reload_weapon_top,
				name	 = "primary_wep_reload",
				label	 = "primary_wep_reload",
				graphics = reload_weapon_graphics,
				type	 = kPush,
				
				command =
					function()
						GUIEventHandler("primary_wep_melee_shot", 1);
					end,
			},]]
			
			NonUniformScaledImage
			{
				x		 = fire_mode_left,
				y		 = fire_mode_top + 3,
				w		 = fire_mode_width - 8,
				h		 = fire_mode_height - 6,
				name	 = "primary_wep_single_shot_img_active",
				label	 = "primary_wep_single_shot_img_active",
				image    = "gui/GroundCombat/small/single_selected",
			},
			NonUniformScaledImage
			{
				x		 = fire_mode_left,
				y		 = fire_mode_top + 3,
				w		 = fire_mode_width - 8,
				h		 = fire_mode_height - 6,
				name	 = "primary_wep_single_shot_img_inactive",
				label	 = "primary_wep_single_shot_img_inactive",
				image    = "gui/GroundCombat/small/single_unselected",
			},
			NonUniformScaledImage
			{
				x		 = fire_mode_left + fire_mode_width + fire_mode_spacing,
				y		 = fire_mode_top + 3,
				w		 = fire_mode_width - 8,
				h		 = fire_mode_height - 6,
				name	 = "primary_wep_burst_fire_img_active",
				label	 = "primary_wep_burst_fire_img_active",
				image    = "gui/GroundCombat/small/burst_selected",
			},
			NonUniformScaledImage
			{
				x		 = fire_mode_left + fire_mode_width + fire_mode_spacing,
				y		 = fire_mode_top + 3,
				w		 = fire_mode_width - 8,
				h		 = fire_mode_height - 6,
				name	 = "primary_wep_burst_fire_img_inactive",
				label	 = "primary_wep_burst_fire_img_inactive",
				image    = "gui/GroundCombat/small/burst_unselected",
			},

			Text
			{
				x	 = primary_wep_clip_size_left,
				y	 = primary_wep_clip_size_top,
				w	 = primary_wep_clip_size_width,
				h	 = 30,
				name = "primary_wep_clip_size",
				text = " ",
				font = XenonautsDefaultFont,
			},
			----------------------
			-- Two Weapons mode --
			----------------------
			
			WeaponButton
			{
				x		 = first_weapon_left,
				y		 = two_weapons_top,
				name	 = "first_weapon",
				label	 = "first_weapon",
				graphics = first_weapon_graphics,
				type	 = kToggle,
				
				command =
					function()
						GUIEventHandler("primary_wep", 1);
					end,
			},
			
			ScalingText
			{
				font = XenonautsDefaultFont,
				name = "first_wep_timer",
				x = primary_wep_clip_size_left + 90,
				y = primary_wep_clip_size_top,
				w = primary_wep_clip_size_width,
				h = 30,
				label = "#--",
				fontScale = 1.0, 
			},
			
			-------------------------------------
			-- Grenade selector & Quick reload --
			-------------------------------------
			QuickThrowButton
			{
				x		 = cbutton_left,
				y		 = cbutton_top,
				name	 = "grenade_selector",
				label	 = "grenade_selector",
				graphics = top_central_buttons_graphics,
				
				command =
					function()
						GUIEventHandler("grenade_selector", 1);
					end,
					
				NonUniformScaledImage
				{
					x		 = kCenter,
					y		 = 2,
					w		 = kMax - 2,
					h		 = kMax - 1,
					name	 = "grenade_image",
					image = "gui/GroundCombat/small/grenade",
				},
				ScalingText
				{
				  font = XenonautsDefaultFont,
				  name = "grenade_counter",
				  x = kMax - 24,
				  y = kMax - 14,
				  w = 20,
				  h = 20,
				  flags = kHAlignRight,
				  label = "#66",
				  fontScale = 1.0,
				},
			},
			TooltipRect
			{
				x = cbutton_left,
				y = cbutton_top,
				w = cbutton_width,
				h = cbutton_height,
				
				text="GcGUI.Tooltips.QuickGrenadeSlot",
				uppercase = false,
			},
			
			Button
			{
				x		 = cbutton_left,
				y		 = cbutton_top + 55,
				name	 = "weapon_reload",
				label	 = "weapon_reload",
				graphics = bottom_central_buttons_graphics,
				type = kPush,
				
				command =
					function()
						GUIEventHandler("weapon_reload", 1);
					end,
					
				NonUniformScaledImage
				{
					x		 = kCenter,
					y		 = 1,
					w		 = kMax - 2,
					h		 = kMax - 1,
					name	 = "ammo_image",
					image    = "weapons/ballistic/assaultrifle_ammo",
				},
				ScalingText
				{
				  font = XenonautsDefaultFont,
				  name = "ammo_counter",
				  x = kMax - 24,
				  y = kMax - 14,
				  w = 20,
				  h = 20,
				  flags = kHAlignRight,
				  label = "#66",
				  fontScale = 1.0,
				},
			},
			TooltipRect
			{
				x = cbutton_left,
				y = cbutton_top + 55,
				w = cbutton_width,
				h = cbutton_height,
				
				text="GcGUI.Tooltips.QuickReloadSlot",
				uppercase = false,
			},
			
			------------------------------
			-- Secondary weapon buttons --
			------------------------------
			
			WeaponButton
			{
				x		 = secondary_wep_btn_left,
				y		 = secondary_wep_btn_top,
				w		 = secondary_wep_btn_width,
				h		 = secondary_wep_btn_height,
				name	 = "secondary_wep",
				label	 = "secondary_wep",
				graphics = second_weapon_graphics,
				type	 = kToggle,
				
				command =
					function()
						GUIEventHandler("secondary_wep", 1);
					end,
			},
			
			BeginGroup(),
			Button
			{
				x		 = fire_mode_left + two_weapons_width + 10,
				y		 = fire_mode_top,
				name	 = "secondary_wep_single_shot",
				label	 = "secondary_wep_single_shot",
				graphics = fire_mode_graphics,
				type	 = kRadio,
				command	=
					function()
						GUIEventHandler("secondary_wep_single_shot", 1);
					end,
			},
			
			Button
			{
				x		 = (fire_mode_left + two_weapons_width + 10) + fire_mode_width + fire_mode_spacing,
				y		 = fire_mode_top,
				name	 = "secondary_wep_burst_fire",
				label	 = "secondary_wep_burst_fire",
				graphics = fire_mode_graphics,
				type	 = kRadio,
				
				command =
					function()
						GUIEventHandler("secondary_wep_burst_fire", 1);
					end,
			},
			BeginGroup(),
			--[[Button
			{
				x		 = reload_weapon_left + two_weapons_width + 10,
				y		 = reload_weapon_top,
				name	 = "secondary_wep_reload",
				label	 = "secondary_wep_reload",
				graphics = reload_weapon_graphics,
				type	 = kPush,
				
				command	=
					function()
						GUIEventHandler("secondary_wep_melee_shot", 1);
					end,
			},]]--
			
			NonUniformScaledImage
			{
				x		 = (fire_mode_left + two_weapons_width + 10),
				y		 = fire_mode_top + 3,
				w		 = fire_mode_width - 8,
				h		 = fire_mode_height - 6,
				name	 = "secondary_wep_single_shot_img_active",
				label	 = "secondary_wep_single_shot_img_active",
				image    = "gui/GroundCombat/small/single_selected",
			},
			NonUniformScaledImage
			{
				x		 = fire_mode_left + two_weapons_width + 10,
				y		 = fire_mode_top + 3,
				w		 = fire_mode_width - 8,
				h		 = fire_mode_height - 6,
				name	 = "secondary_wep_single_shot_img_inactive",
				label	 = "secondary_wep_single_shot_img_inactive",
				image    = "gui/GroundCombat/small/single_unselected",
			},
			NonUniformScaledImage
			{
				x		 = (fire_mode_left + two_weapons_width + 10) + fire_mode_width + fire_mode_spacing,
				y		 = fire_mode_top + 3,
				w		 = fire_mode_width - 8,
				h		 = fire_mode_height - 6,
				name	 = "secondary_wep_burst_fire_img_active",
				label	 = "secondary_wep_burst_fire_img_active",
				image    = "gui/GroundCombat/small/burst_selected",
			},
			NonUniformScaledImage
			{
				x		 = (fire_mode_left + two_weapons_width + 10) + fire_mode_width + fire_mode_spacing,
				y		 = fire_mode_top + 3,
				w		 = fire_mode_width - 8,
				h		 = fire_mode_height - 6,
				name	 = "secondary_wep_burst_fire_img_inactive",
				label	 = "secondary_wep_burst_fire_img_inactive",
				image    = "gui/GroundCombat/small/burst_unselected",
			},

			Text
			{
				x	 = secondary_wep_clip_size_left,
				y	 = secondary_wep_clip_size_top,
				w	 = secondary_wep_clip_size_width,
				h	 = 30,
				name = "secondary_wep_clip_size",
				text = "",
				font = XenonautsDefaultFont,
			},
			
			ScalingText
			{
				font = XenonautsDefaultFont,
				name = "second_wep_timer",
				x = secondary_wep_clip_size_left + 90,
				y = secondary_wep_clip_size_top,
				w = secondary_wep_clip_size_width,
				h = 30,
				label = "#--",
				fontScale = 1.0, 
			},
				
			------------------------------
			-- End turn button          --
			------------------------------
			
			Button
			{
				x		 = end_turn_left,
				y		 = end_turn_top,
				name	 = "end_turn",
				label	 = "end_turn",
				graphics = end_turn_graphics,
				mask	 = "gui/GroundCombat/small/endturn_pressed_mask",
				
				command =
					function()
						GUIEventHandler("end_turn", 1);
					end,
			},
			TooltipRect
			{
				x = end_turn_left,
				y = end_turn_top,
				w = 82,
				h = 53,
				
				text="GcGUI.Tooltips.EndTurnButton",
				uppercase = false,
			},
			------------------------
			-- Camera +/- buttons --
			------------------------
			Button
			{
				x		 = camerazoomout_left,
				y		 = camerazoomout_top,
				w		 = camerazoomout_width,
				h		 = camerazoomout_height,
				name	 = "camerazoomout",
				label	 = "camerazoomout",
				graphics = camerazoomout_graphics,
				type     = kPush,

				command =
					function()
						GUIEventHandler("camerazoomout", 1);
					end,
			},
			
			Button
			{
				x		 = camerazoomin_left,
				y		 = camerazoomin_top,
				w		 = camerazoomin_width,
				h		 = camerazoomin_height,
				name	 = "camerazoomin",
				label	 = "camerazoomin",
				graphics = camerazoomin_graphics,
				type     = kPush,

				command =
					function()
						GUIEventHandler("camerazoomin", 1);
					end,
			},
			-------------------
			-- Camera levels --
			-------------------
			Button
			{
				x	=	camerazoomin_left,
				y	= 	camerazoomin_top + (cameralevel_height+1) * 6,
				w	=	camerazoomin_width,
				h	=	camerazoomin_height,
				name=	"camerazoomlevel_0",
				graphics	=	cameralevel_graphics,
				type = kToggle,
				on = true,
				
				command =
					function()
						GUIEventHandler("zoomlevel_0", 1);
					end,
			},
			Button
			{
				x	=	camerazoomin_left,
				y	= 	camerazoomin_top + (cameralevel_height+1) * 5,
				w	=	camerazoomin_width,
				h	=	camerazoomin_height,
				name=	"camerazoomlevel_1",
				graphics	=	cameralevel_graphics,
				type = kToggle,
				
				command =
					function()
						GUIEventHandler("zoomlevel_1", 1);
					end,
			},
			Button
			{
				x	=	camerazoomin_left,
				y	= 	camerazoomin_top + (cameralevel_height+1) * 4,
				w	=	camerazoomin_width,
				h	=	camerazoomin_height,
				name=	"camerazoomlevel_2",
				graphics	=	cameralevel_graphics,
				type = kToggle,
				
				command =
					function()
						GUIEventHandler("zoomlevel_2", 1);
					end,
			},
			Button
			{
				x	=	camerazoomin_left,
				y	= 	camerazoomin_top + (cameralevel_height+1) * 3,
				w	=	camerazoomin_width,
				h	=	camerazoomin_height,
				name=	"camerazoomlevel_3",
				graphics	=	cameralevel_graphics,
				type = kToggle,
				
				command =
					function()
						GUIEventHandler("zoomlevel_3", 1);
					end,
			},
			Button
			{
				x	=	camerazoomin_left,
				y	= 	camerazoomin_top + (cameralevel_height+1) * 2,
				w	=	camerazoomin_width,
				h	=	camerazoomin_height,
				name=	"camerazoomlevel_4",
				graphics	=	cameralevel_graphics,
				type = kToggle,
				
				command =
					function()
						GUIEventHandler("zoomlevel_4", 1);
					end,
			},
			Button
			{
				x	=	camerazoomin_left,
				y	= 	camerazoomin_top + (cameralevel_height+1) * 1,
				w	=	camerazoomin_width,
				h	=	camerazoomin_height,
				name=	"camerazoomlevel_5",
				graphics	=	cameralevel_graphics,
				type = kToggle,
				
				command =
					function()
						GUIEventHandler("zoomlevel_5", 1);
					end,
			},
			
			
			TooltipRect
			{
				x = camerazoomin_left,
				y = camerazoomin_top,
				w = 52,
				h = 100,
				
				text="GcGUI.Tooltips.CameraLevelControl",
				uppercase = false,
			},
			
			----------------------
			-- Grenade selector --
			----------------------
			
			TiledImage
			{
			  name = "grenadeselector_tile",
			  x = primary_wep_btn_left,
			  y = primary_wep_btn_top,
			  w = primary_wep_btn_width,
			  h = primary_wep_btn_height,
			  image = "gui/GroundCombat/small/background_2handed",
			  bordersize = 2,
			  
			  ScalingText
				{
				  font = XenonautsDefaultFont,
				  name = "selected_grenade_name",
				  x = 18,
				  y = 15,
				  w = 100,
				  h = 20,
				  flags = kHAlignLeft,
				  label = "#Nerve gas grenade",
				  fontScale = 1.0,
				},
				ScalingText
				{
				  font = XenonautsDefaultFont,
				  name = "throw_cost_text",
				  x = 25,
				  y = 35,
				  w = 100,
				  h = 20,
				  flags = kHAlignLeft,
				  label = "#Throw cost: 15 AP",
				  fontScale = 0.9,
				},
				ScalingText
				{
				  font = XenonautsDefaultFont,
				  name = "full_hands_text",
				  x = 25,
				  y = 50,
				  w = 100,
				  h = 20,
				  flags = kHAlignLeft,
				  label = "#hands full: 12 AP",
				  fontScale = 0.9,
				},
				ScalingText
				{
				  font = XenonautsDefaultFont,
				  name = "total_cost_text",
				  x = 25,
				  y = 65,
				  w = 100,
				  h = 20,
				  flags = kHAlignLeft,
				  
				  label = "#total cost: 27 AP",
				  fontScale = 0.9,
				},
			  
				--row
				Button
				{
					x		 = kMax - (grenadebutton_width + 3)*3 - 14,
					y		 = kMax - (grenadebutton_height + 3)*2 - 11,
					name	 = "grenade_select1",
					label	 = "grenade_select1",
					graphics = grenade_button_graphics,
					
					command =
						function()
							GUIEventHandler("grenade1", 1);
						end,
						
					NonUniformScaledImage
					{
						x		 = kCenter,
						y		 = kCenter,
						w		 = kMax,
						h		 = kMax,
						name	 = "grenade1_image",
						image = f,
					},
					ScalingText
					{
					  font = XenonautsDefaultFont,
					  name = "grenade1_counter",
					  x = kMax,
					  y = kMax - 20,
					  w = 20,
					  h = 20,
					  flags = kHAlignRight,
					  label = "#6",
					  fontScale = 1.0,
					},
				},
				
				Button
				{
					x		 = kMax - (grenadebutton_width + 3)*2 - 14,
					y		 = kMax - (grenadebutton_height + 3)*2 - 11,
					name	 = "grenade_select2",
					label	 = "grenade_select2",
					graphics = grenade_button_graphics,
					
					command =
						function()
							GUIEventHandler("grenade2", 1);
						end,
						
					NonUniformScaledImage
					{
						x		 = kCenter,
						y		 = kCenter,
						w		 = kMax,
						h		 = kMax,
						name	 = "grenade2_image",
						image = f,
					},
					ScalingText
					{
					  font = XenonautsDefaultFont,
					  name = "grenade2_counter",
					  x = kMax,
					  y = kMax - 20,
					  w = 20,
					  h = 20,
					  flags = kHAlignRight,
					  label = "#6",
					  fontScale = 1.0,
					},
				},
				
				Button
				{
					x		 = kMax - (grenadebutton_width + 3)*1 - 14,
					y		 = kMax - (grenadebutton_height + 3)*2 - 11,
					name	 = "grenade_select3",
					label	 = "grenade_select3",
					graphics = grenade_button_graphics,
					
					command =
						function()
							GUIEventHandler("grenade3", 1);
						end,
						
					NonUniformScaledImage
					{
						x		 = kCenter,
						y		 = kCenter,
						w		 = kMax,
						h		 = kMax,
						name	 = "grenade3_image",
						image = f,
					},
					ScalingText
					{
					  font = XenonautsDefaultFont,
					  name = "grenade3_counter",
					  x = kMax,
					  y = kMax - 20,
					  w = 20,
					  h = 20,
					  flags = kHAlignRight,
					  label = "#6",
					  fontScale = 1.0,
					},
				},
				--new row
				Button
				{
					x		 = kMax - (grenadebutton_width + 3)*3 - 14,
					y		 = kMax - (grenadebutton_height + 3)*1 - 11,
					name	 = "grenade_select4",
					label	 = "grenade_select4",
					graphics = grenade_button_graphics,
					
					command =
						function()
							GUIEventHandler("grenade4", 1);
						end,
						
					NonUniformScaledImage
					{
						x		 = kCenter,
						y		 = kCenter,
						w		 = kMax,
						h		 = kMax,
						name	 = "grenade4_image",
						image = f,
					},
					ScalingText
					{
					  font = XenonautsDefaultFont,
					  name = "grenade4_counter",
					  x = kMax,
					  y = kMax - 20,
					  w = 20,
					  h = 20,
					  flags = kHAlignRight,
					  label = "#6",
					  fontScale = 1.0,
					},
				},
				Button
				{
					x		 = kMax - (grenadebutton_width + 3)*2 - 14,
					y		 = kMax - (grenadebutton_height + 3)*1 - 11,
					name	 = "grenade_select5",
					label	 = "grenade_select5",
					graphics = grenade_button_graphics,
					
					command =
						function()
							GUIEventHandler("grenade5", 1);
						end,
						
					NonUniformScaledImage
					{
						x		 = kCenter,
						y		 = kCenter,
						w		 = kMax,
						h		 = kMax,
						name	 = "grenade5_image",
						image = f,
					},
					ScalingText
					{
					  font = XenonautsDefaultFont,
					  name = "grenade5_counter",
					  x = kMax,
					  y = kMax - 20,
					  w = 20,
					  h = 20,
					  flags = kHAlignRight,
					  label = "#6",
					  fontScale = 1.0,
					},
				},
				Button
				{
					x		 = kMax - (grenadebutton_width + 3)*1 - 14,
					y		 = kMax - (grenadebutton_height + 3)*1 - 11,
					name	 = "grenade_select6",
					label	 = "grenade_select6",
					graphics = grenade_button_graphics,
					
					command =
						function()
							GUIEventHandler("grenade6", 1);
						end,
						
					NonUniformScaledImage
					{
						x		 = kCenter,
						y		 = kCenter,
						w		 = kMax,
						h		 = kMax,
						name	 = "grenade6_image",
						image = f,
					},
					ScalingText
					{
					  font = XenonautsDefaultFont,
					  name = "grenade6_counter",
					  x = kMax,
					  y = kMax - 20,
					  w = 20,
					  h = 20,
					  flags = kHAlignRight,
					  label = "#6",
					  fontScale = 1.0,
					},
				},
				
			},
		},	
	},		
};
