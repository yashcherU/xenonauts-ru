require "scripts/style"

MakeDialog
{
	name = "explanatoryTooltipDlg",
	GSDialog
	{
 	x = kCenter,
    y = kCenter,
    
    fit = true,
	movable = true,
    
	  TiledImage
	  {
		  name  = "backgroundimage",
		  image = "uitextures/transparent",
  		w     = 330 * screenScaleX,
  		h     = 145 * screenScaleY,
  		bordersize = 2,
  		
  		sizetochildren = true,
  		sizetochildrenborder = 5,
  		
      ScalingText
      {
        name = "name",
        x = 5,
        y = 0,
        w = kMax - 5,
        h = 60 * screenScaleY,
        flags = kHAlignCenter + kVAlignCenter,
        label = explanatoryTooltipTitle,
        font = XenonautsLabelFontMedium,
        fontScale = 1.2*screenScaleY,
      },
	  ScalingText
      {
        name = "message",
        x = 10 * screenScaleY,
        y = 0,
        w = kMax - (20 * screenScaleY),
        h = 105 * screenScaleY,
        flags = kHAlignLeft + kVAlignCenter,
        label = explanatoryTooltipText,
        font = XenopediaMain,
        fontScale = 1.05*screenScaleY,
      },

	  
        
      SetStyle( XenonautsTiledButton2Style ),
      TiledButton
      {
        name = "cancel",
        default = true,
        cancel = true,
        x = 5,
        y = 0,
        w = kMax - 5,
        h = 20 * screenScaleY,
    		bordersize = 2,
        label = "OK",
        font = XenonautsLabelFontMedium,
        fontScale = screenScaleY,
        
        command = 
          function()
	          PopModal( "explanatoryTooltipDlg" );
	          MessageBoxClosed();
          end,
      },
	  },
	},
}
