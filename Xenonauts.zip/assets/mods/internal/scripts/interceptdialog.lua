require "scripts/style"

local targetName = "";
if ( gDialogTable.targetName ) then
	targetName = gDialogTable.targetName;
end

interceptDialogColor = {
  color = Color( 44, 56, 68, 255 );
};

MakeDialog
{
	name = "interceptdialog",
	InterceptDialog
	{
 	  x = kCenter,
    y = kCenter,
    
    fit = true,
	
	movable = true,
    
    target = targetName;
    
	  TiledImage
	  {
		  name  = "backgroundimage",
		  image = "uitextures/transparent",
  		w     = 595 * screenScaleY,
  		h     = 400 * screenScaleY,
  		bordersize = 2,
 
      ScalingText
      {
        name = "static",
        x = 5,
        y = 0,
        w = kMax - 5,
        h = 62 * screenScaleY,
        flags = kHAlignCenter + kVAlignCenter,
        label = "InterceptDialog.Title",
        font = XenonautsLabelFontMediumPlus,
        fontScale = screenScaleY * 1.2,
        outline = 1,
      },

      TitledFrame
      {
	      name  = "static",
        x = 5,
        y = 65 + 14 * screenScaleY + 5,
        w = 105 * screenScaleY,
        h = kMax - 30 * screenScaleY - 10,
        headimage = "uitextures/frametop",
        bodyimage = "uitextures/research/framebottomcol",
        bordersize = 2,
        headersize = 18 * screenScaleY,
        
        ScalingText
        {
          font = MenuElementSubHeading,
          name = "static",
          x = 0,
          y = 0,
          w = kMax,
          h = 18 * screenScaleY,
          fontScale = screenScaleY * 0.9,
  	      flags = kHAlignCenter + kVAlignCenter,
          label = "InterceptDialog.AcName",
          outline = 1,
        },
      },

      TitledFrame
      {
	      name  = "static",
        x = 10 + Floor( 105 * screenScaleY ),
        y = 65 + 14 * screenScaleY + 5,
        w = 110 * screenScaleY,
        h = kMax - 30 * screenScaleY - 10,
        headimage = "uitextures/frametop",
        bodyimage = "uitextures/research/framebottomcol",
        bordersize = 2,
        headersize = 18 * screenScaleY,
        
        ScalingText
        {
          font = MenuElementSubHeading,
          name = "static",
          x = 0,
          y = 0,
          w = kMax,
          h = 18 * screenScaleY,
          fontScale = screenScaleY * 0.9,
  	      flags = kHAlignCenter + kVAlignCenter,
          label = "InterceptDialog.BaseName",
          outline = 1,
        },
      },

      TitledFrame
      {
	      name  = "static",
        x = 15 + Floor( 105 * screenScaleY ) + Floor( 110 * screenScaleY ),
        y = 65 + 14 * screenScaleY + 5,
        w = 55 * screenScaleY,
        h = kMax - 30 * screenScaleY - 10,
        headimage = "uitextures/frametop",
        bodyimage = "uitextures/research/framebottomcol",
        bordersize = 2,
        headersize = 18 * screenScaleY,
        
        ScalingText
        {
          font = MenuElementSubHeading,
          name = "static",
          x = 0,
          y = 0,
          w = kMax,
          h = 18 * screenScaleY,
          fontScale = screenScaleY * 0.9,
  	      flags = kHAlignCenter + kVAlignCenter,
          label = "InterceptDialog.ETA",
          outline = 1,
        },
      },

      TitledFrame
      {
	      name  = "static",
        x = 20 + Floor( 105 * screenScaleY ) + Floor( 110 * screenScaleY ) + Floor( 55 * screenScaleY ),
        y = 65 + 14 * screenScaleY + 5,
        w = 55 * screenScaleY,
        h = kMax - 30 * screenScaleY - 10,
        headimage = "uitextures/frametop",
        bodyimage = "uitextures/research/framebottomcol",
        bordersize = 2,
        headersize = 18 * screenScaleY,
        
        ScalingText
        {
          font = MenuElementSubHeading,
          name = "static",
          x = 0,
          y = 0,
          w = kMax,
          h = 18 * screenScaleY,
          fontScale = screenScaleY * 0.9,
  	      flags = kHAlignCenter + kVAlignCenter,
          label = "ICEPTDIALOG.HEALTH",
          outline = 1,
        },
      },

      TitledFrame
      {
	      name  = "static",
        x = 25 + Floor( 105 * screenScaleY ) + Floor( 110 * screenScaleY ) + Floor( 55 * screenScaleY ) * 2,
        y = 65 + 14 * screenScaleY + 5,
        w = 55 * screenScaleY,
        h = kMax - 30 * screenScaleY - 10,
        headimage = "uitextures/frametop",
        bodyimage = "uitextures/research/framebottomcol",
        bordersize = 2,
        headersize = 18 * screenScaleY,
        
        ScalingText
        {
          font = MenuElementSubHeading,
          name = "static",
          x = 0,
          y = 0,
          w = kMax,
          h = 18 * screenScaleY,
          fontScale = screenScaleY * 0.9,
  	      flags = kHAlignCenter + kVAlignCenter,
          label = "InterceptDialog.Ammo",
          outline = 1,
        },
      },

      TitledFrame
      {
	      name  = "static",
        x = 30 + Floor( 105 * screenScaleY ) + Floor( 110 * screenScaleY ) + Floor( 55 * screenScaleY ) * 3,
        y = 65 + 14 * screenScaleY + 5,
        w = 55 * screenScaleY,
        h = kMax - 30 * screenScaleY - 10,
        headimage = "uitextures/frametop",
        bodyimage = "uitextures/research/framebottomcol",
        bordersize = 2,
        headersize = 18 * screenScaleY,
        
        ScalingText
        {
          font = MenuElementSubHeading,
          name = "static",
          x = 0,
          y = 0,
          w = kMax,
          h = 18 * screenScaleY,
          fontScale = screenScaleY * 0.9,
  	      flags = kHAlignCenter + kVAlignCenter,
          label = "InterceptDialog.Fuel",
          outline = 1,
        },
      },

      TitledFrame
      {
	      name  = "static",
        x = 35 + Floor( 105 * screenScaleY ) + Floor( 110 * screenScaleY ) + Floor( 55 * screenScaleY ) * 4,
        y = 65 + 14 * screenScaleY + 5,
        w = 110 * screenScaleY,
        h = kMax - 30 * screenScaleY - 10,
        headimage = "uitextures/frametop",
        bodyimage = "uitextures/research/framebottomcol",
        bordersize = 2,
        headersize = 18 * screenScaleY,
        
        ScalingText
        {
          font = MenuElementSubHeading,
          name = "static",
          x = 0,
          y = 0,
          w = kMax,
          h = 18 * screenScaleY,
          fontScale = screenScaleY * 0.9,
  	      flags = kHAlignCenter + kVAlignCenter,
          label = "InterceptDialog.Status",
          outline = 1,
        },
      },

      ListControl
      {
	      name  = "airplanelist",
        x = 5,
        y = 65 + 14 * screenScaleY + 5 + ( 18 * screenScaleY + 3 ),
        w = kMax - 5,
        h = kMax - 30 * screenScaleY - 13,
        font = MenuElementSubHeading,
        fontScale = screenScaleY * 0.9,
        selectionLimit = 3;
        
        column1x = 0,
        column1w = 105 * screenScaleY,
        column2x = 105 * screenScaleY + 5,
        column2w = 110 * screenScaleY,
        column3x = Floor( 105 * screenScaleY ) + Floor( 110 * screenScaleY ) + 10,
        column3w = 55 * screenScaleY,
        column4x = Floor( 105 * screenScaleY ) + Floor( 110 * screenScaleY ) + Floor( 55 * screenScaleY ) + 15,
        column4w = 55 * screenScaleY,
        column5x = Floor( 105 * screenScaleY ) + Floor( 110 * screenScaleY ) + Floor( 55 * screenScaleY ) * 2 + 20,
        column5w = 55 * screenScaleY,
        column6x = Floor( 105 * screenScaleY ) + Floor( 110 * screenScaleY ) + Floor( 55 * screenScaleY ) * 3 + 25,
        column6w = 55 * screenScaleY,
        column7x = Floor( 105 * screenScaleY ) + Floor( 110 * screenScaleY ) + Floor( 55 * screenScaleY ) * 4 + 30,
        column7w = 110 * screenScaleY,

        TiledImage
        {
          name = "scrollbar",
          x = kMax - 7,
          y = 0,
          w = kMax,
          h = kMax,
          image = "uitextures/scrollbar",
          bordersize = 4,

          NonUniformScaledImage
	        {
		        name  = "scrollbarBtn",
	          x = 2,
	          y = 2,
	          w = 3,
	          h = 5,
		        image = "uitextures/white",
	        },
        },
      },
      
   	  TiledImage
  	  {
	  	  name  = "backgroundimage",
		    image = "uitextures/buttonframeup",
        x = 30 * screenScaleY,
        y = kMax - 30 * screenScaleY - 5,
        w = Floor( 300 * screenScaleY ),
        h = 30 * screenScaleY,
  		  bordersize = 2,

        ScalingText
        {
          font = XenonautsLabelFontMediumPlus,
          name = "static",
          x = -20 * screenScaleY,
          y = 0,
          w = ( Floor( 615 * screenScaleY ) / 2 - 2 - Floor( 100 * screenScaleY ) ) / 2,
          h = kMax,
          fontScale = screenScaleY * 0.9,
  	      flags = kHAlignCenter + kVAlignCenter,
          label = "InterceptDialog.Target",
          outline = 1,
        },
        ScalingText
        {
          font = XenonautsLabelFontMediumPlus,
          name = "target",
          x = ( Floor( 515 * screenScaleY ) / 2 - 2 - Floor( 100 * screenScaleY ) ) / 2,
          y = 0,
          w = Floor( 190 * screenScaleY ),
          h = kMax,
          fontScale = screenScaleY * 0.9,
  	      flags = kVAlignCenter,
          label = "undefined",
          outline = 1,
        },
  		},

      SetStyle( XenonautsTiledButton3Style ),
      TiledButton
      {
        name = "launch",
        default = true,
        x = Floor( 865 * screenScaleY ) / 2 + 3,
        y = kMax - 30 * screenScaleY - 5,
        w = 130 * screenScaleY,
        h = 30 * screenScaleY,
    		bordersize = 2,
        label = "Launch",
		outline = 1,
        font = XenonautsLabelFontMediumPlus,
        fontScale = screenScaleY,

        
        command = 
          function()
	          MessageBoxClosed();
	          PopModal( "interceptdialog" );
	          OnLaunchButton();
          end,
      },
      SetStyle( XenonautsTiledButton2Style ),
	  TiledButton
      {
        name = "cancel",
        cancel = true,
        x = kMax - 50 * screenScaleY - 2,
        y = 2,
        w = kMax - 2,
        h = 20 * screenScaleY,
    		bordersize = 2,
        label = "X",
        font = XenonautsLabelFontMedium,
        fontScale = screenScaleY*1.2,
        
        command = 
          function()
	          PopModal( "interceptdialog" );
	          MessageBoxClosed();
			  NormalMode( false );
          end,
      },
	  },
	},
}

gDialogTable = {}