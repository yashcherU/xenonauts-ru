require "scripts/style"


MissionStatusFont =
{
	GeoscapeFont,
	35,
	WhiteColor,
};

ResultsFont = {
  GeoscapeFont,
  13,
  WhiteColor,
};

--
local windowWidth  = screenResolutionW * 0.95;
local windowHeight = screenResolutionH * 1.00;
local windowXPos   = ( screenResolutionW - windowWidth  ) / 2;
local windowYPos   = ( screenResolutionH - windowHeight ) / 2;

local frame   = 20; -- GSDialog frame
local padding = 15; -- extra padding between frame and content
local mainAreaH = windowHeight - 2*frame - 2*padding;
local mainAreaW = windowWidth  - 2*frame - 2*padding;

local leftColumnWidth  = mainAreaW * 0.45;
local rightColumnWidth = mainAreaW * 0.55;

local itemslistCol1 = ( leftColumnWidth - padding ) * 0.40;
local itemslistCol2 = ( leftColumnWidth - padding ) * 0.60;

local leftColumnArea1H = mainAreaH * 0.15; -- "Mission successful / failure!"
local leftColumnArea2H = mainAreaH * 0.30; -- Result box
local leftColumnArea3H = mainAreaH * 0.10; -- "Items recovered:"
local leftColumnArea4H = mainAreaH * 0.35; -- items box
local leftColumnArea5H = mainAreaH * 0.05; -- "Total sale value"
local leftColumnArea6H = mainAreaH * 0.05; -- "OK" button

local area2LineHeight = Floor( ( leftColumnArea2H - 60 ) / 12 );
local area4LineHeight = Floor( ( leftColumnArea4H - 70 ) / 14 );

local screenScale = 0.0;
if (screenScaleX < screenScaleY) then
	screenScale = screenScaleX;
else
	screenScale = screenScaleY;
end


MakeDialog
{
	name = "endCombatDlg",

	EndCombat
	{
		x = windowXPos + frame + padding,
		y = windowYPos + frame,
		w = mainAreaW,
		h = kMax - frame,

		NonUniformScaledImage
		{
			x = 0,
			y = 0,
			w = kMax,
			h = kMax,
			image = "uitextures/gsdialog/bg",
		},

		Window
		{
			x = padding,
			y = padding,
			w = leftColumnWidth,
			h = kMax - padding,

			ScalingText
			{
				name = "missionStatus",
				font = MissionStatusFont,
				x = 0,
				y = 0,
				w = kMax,
				h = leftColumnArea1H,
				label = "GC.MissionEnd.Result.Success",
				flags = kHAlignCenter + kVAlignCenter,
				fontScale = 1.0 * screenScaleY,
			},

			TiledImage
			{
				name = "resultBox",
				x = 0,
				y = leftColumnArea1H,
				w = kMax,
				h = leftColumnArea2H,
				image = "uitextures/gsdialog/buttonframeup",
				bordersize = 2,

				DottedLabelsContainer
				{
					name = "dottedLabelsCtr",
					x = 0,
					y = 0,
					w = kMax,
					h = leftColumnArea2H,

					justifyDots  = true,
					leftPadding  = screenResolutionW * 0.010,
					rightPadding = screenResolutionW * 0.010,

					DottedLabel
					{
						font = ResultsFont,
						name = "aliensKilled",
						x = screenResolutionW * 0.010,
						y = 1 * ( 0 + area2LineHeight ),
						w = kMax - screenResolutionW * 0.010,
						h = area2LineHeight,
						left = "GC.MissionEnd.AliensKilled",
						right = "undefined",
						leftcolor = WhiteColor,
						dotscolor = WhiteColor,
						rightcolor = WhiteColor,
						flags = kVAlignCenter,
						fontScale = screenScaleY,
					},
					ScalingText
					{
						font = ResultsFont,
						name = "aliensKilledRating",
						x = screenResolutionW * 0.010,
						y = 2 * ( 0 + area2LineHeight ),
						w = kMax - screenResolutionW * 0.010,
						h = area2LineHeight,
						label = "undefined",
						flags = kVAlignCenter,
						fontScale = screenScaleY,
					},
					
					DottedLabel
					{
						font = ResultsFont,
						name = "xenonautsLost",
						x = screenResolutionW * 0.010,
						y = 4 * ( 0 + area2LineHeight ),
						w = kMax - screenResolutionW * 0.010,
						h = area2LineHeight,
						left = "GC.MissionEnd.XenonautsLost",
						right = "undefined",
						leftcolor = WhiteColor,
						dotscolor = WhiteColor,
						rightcolor = WhiteColor,
						flags = kVAlignCenter,
						fontScale = screenScaleY,
					},
					DottedLabel
					{
						font = ResultsFont,
						name = "vehiclesLost",
						x = screenResolutionW * 0.010,
						y = 5 * ( 0 + area2LineHeight ),
						w = kMax - screenResolutionW * 0.010,
						h = area2LineHeight,
						left = "GC.MissionEnd.VehiclesLost",
						right = "undefined",
						leftcolor = WhiteColor,
						dotscolor = WhiteColor,
						rightcolor = WhiteColor,
						flags = kVAlignCenter,
						fontScale = screenScaleY,
					},
					ScalingText
					{
						font = ResultsFont,
						name = "unitsLostRating",
						x = screenResolutionW * 0.010,
						y = 6 * ( 0 + area2LineHeight ),
						w = kMax - screenResolutionW * 0.010,
						h = area2LineHeight,
						label = "undefined",
						flags = kVAlignCenter,
						fontScale = screenScaleY,
					},
					
					DottedLabel
					{
						font = ResultsFont,
						name = "survivingLocalForces",
						x = screenResolutionW * 0.010,
						y = 8 * ( 0 + area2LineHeight ),
						w = kMax - screenResolutionW * 0.010,
						h = area2LineHeight,
						left = "GC.MissionEnd.SurvivingLocalForces",
						right = "undefined",
						leftcolor = WhiteColor,
						dotscolor = WhiteColor,
						rightcolor = WhiteColor,
						flags = kVAlignCenter,
						fontScale = screenScaleY,
					},
					DottedLabel
					{
						font = ResultsFont,
						name = "survivingCivilians",
						x = screenResolutionW * 0.010,
						y = 9 * ( 0 + area2LineHeight ),
						w = kMax - screenResolutionW * 0.010,
						h = area2LineHeight,
						left = "GC.MissionEnd.SurvivingCivilians",
						right = "undefined",
						leftcolor = WhiteColor,
						dotscolor = WhiteColor,
						rightcolor = WhiteColor,
						flags = kVAlignCenter,
						fontScale = screenScaleY,
					},
					ScalingText
					{
						font = ResultsFont,
						name = "survivorsRating",
						x = screenResolutionW * 0.010,
						y = 10 * ( 0 + area2LineHeight ),
						w = kMax - screenResolutionW * 0.010,
						h = area2LineHeight,
						label = "undefined",
						flags = kVAlignCenter,
						fontScale = screenScaleY,
					},
				},
			},


			ScalingText
			{
				name = "ItemsRecovered",
				font = MissionStatusFont,
				x = 0,
				y = leftColumnArea1H + leftColumnArea2H,
				w = kMax,
				h = leftColumnArea3H - 5,
				label = "GC.MissionEnd.ItemsRecovered",
				flags = kHAlignCenter + kVAlignBottom,
				fontScale = 0.6 * screenScaleY,
			},

			TiledImage
			{
				name = "ItemsBox",
				x = 0,
				y = leftColumnArea1H + leftColumnArea2H + leftColumnArea3H,
				w = kMax,
				h = leftColumnArea4H,
				image = "uitextures/gsdialog/buttonframeup",
				bordersize = 2,
				
				ListControl
				{
					name = "itemslist",
					x = 2,
					y = 2,
					w = kMax-2,
					h = kMax-2,
					font = ResultsFont,
					fontScale = screenScaleY,
					hswl = true,
					ignoreMouse = true,
					drawSelection = false,

					column1x = screenResolutionW * 0.010,
					column1w = itemslistCol1 + itemslistCol2,
					column2x = itemslistCol1 * 1.45 + screenResolutionW * 0.010,
					column2w = itemslistCol2 - itemslistCol1 * 0.47 -screenResolutionW * 0.010,


					TiledImage
					{
						name = "scrollbar",
						x = kMax - 8,
						y = 0,
						w = kMax,
						h = kMax,
						image = "ui_screens/xenopedia/scrollbar",
						bordersize = 4,

						NonUniformScaledImage
						{
							name  = "scrollbarBtn",
							x = 2,
							y = 2,
							w = 4,
							h = 5,
							image = "ui_screens/xenopedia/white",
						},
					},
				},
			},

			ScalingText
			{
				name = "TotalSale",
				font = ResultsFont,
				x = 0,
				y = leftColumnArea1H + leftColumnArea2H + leftColumnArea3H + leftColumnArea4H,
				w = kMax,
				h = leftColumnArea5H - 5,
				label = "GC.MissionEnd.TotalSales",
				flags = kHAlignLeft + kVAlignTop,
				fontScale = screenScaleY,
			},
			ScalingText
			{
				name = "TotalSaleValue",
				font = ResultsFont,
				x = 0,
				y = leftColumnArea1H + leftColumnArea2H + leftColumnArea3H + leftColumnArea4H,
				w = kMax - screenResolutionW * 0.015,
				h = leftColumnArea5H - 5,
				label = "undefined",
				flags = kHAlignRight + kVAlignTop,
				fontScale = screenScaleY,
			},

			SetStyle( XenonautsTiledButton2Style ),
			TiledButton
			{
				name = "closedialog",
			        default = true,
			        cancel = true,
				x = 0,
				y = leftColumnArea1H + leftColumnArea2H + leftColumnArea3H + leftColumnArea4H + leftColumnArea5H,
				w = kMax,
				h = leftColumnArea6H,
				bordersize = 2,
				label = "OK",
				font = ResultsFont,
				fontScale = screenScaleY,

				command = 
					function()
						PopModal( "endCombatDlg" );
					end,
			},
		},
		
		-- RIGHT COLUMN
		Window
		{
			x = leftColumnWidth + padding,
			y = 0,
			w = rightColumnWidth,
			h = kMax,
				
			TiledImage
			{
				name = "ItemsBox",
				x = 10,
				y = padding,
				w = kMax - 2*padding,
				h = kMax - padding,
				image = "uitextures/gsdialog/buttonframeup",
				bordersize = 2,
				
				ListControl
				{
					name = "soldierslist",
					x = 2,
					y = 5,
					w = kMax-5,
					h = kMax-5,
					font = ResultsFont,
					fontScale = screenScaleY,
					hswl = false,
					ignoreMouse = true,
					drawSelection = false,
					
					column1x = 5,
					column1w = rightColumnWidth - 2*padding - 35,

					TiledImage
					{
						name = "scrollbar",
						x = kMax - 8,
						y = 0,
						w = kMax,
						h = kMax,
						image = "ui_screens/xenopedia/scrollbar",
						bordersize = 4,

						NonUniformScaledImage
						{
							name  = "scrollbarBtn",
							x = 2,
							y = 2,
							w = 4,
							h = 5,
							image = "ui_screens/xenopedia/white",
						},
					},
				},
			},
		},
	},
}
